import dataclasses
import typing

SEType_Any = typing.Union[
    "SEType_u8",
    "SEType_u16",
    "SEType_u32",
    "SEType_s32",
    "SEType_u64",
    "SEType_f64",
    "SEType_Point2D",
    "SEType_Point3D",
    "SEType_Vect2D",
    "SEType_Vect3D",
    "SEType_Quaternion",
    "SEType_String",
    "SEType_Vector",
    "SEType_Struct",
    "SEType_WorldIntersection",
    "SEType_WorldIntersections",
    "SEType_WorldConeIntersections",
    "SEType_UserMarker",
]

SEType_u8 = typing.NewType("SEType_u8", int)
SEType_u16 = typing.NewType("SEType_u16", int)
SEType_u32 = typing.NewType("SEType_u32", int)
SEType_s32 = typing.NewType("SEType_s32", int)
SEType_u64 = typing.NewType("SEType_u64", int)
SEType_f64 = typing.NewType("SEType_f64", float)


@dataclasses.dataclass(frozen=True)
class SEType_Point2D:
    x: SEType_f64
    y: SEType_f64


@dataclasses.dataclass(frozen=True)
class SEType_Point3D:
    x: SEType_f64
    y: SEType_f64
    z: SEType_f64


@dataclasses.dataclass(frozen=True)
class SEType_Vect2D:
    x: SEType_f64
    y: SEType_f64


@dataclasses.dataclass(frozen=True)
class SEType_Vect3D:
    x: SEType_f64
    y: SEType_f64
    z: SEType_f64


@dataclasses.dataclass(frozen=True, kw_only=True)
class SEType_Quaternion:
    w: SEType_f64
    x: SEType_f64
    y: SEType_f64
    z: SEType_f64


SEType_String = typing.NewType("SEType_String", str)

_VectorItemT = typing.TypeVar(
    "_VectorItemT",
    "SEType_u8",
    "SEType_u16",
    "SEType_u32",
    "SEType_s32",
    "SEType_u64",
    "SEType_f64",
    "SEType_Point2D",
    "SEType_Point3D",
    "SEType_Vect2D",
    "SEType_Vect3D",
    "SEType_Quaternion",
    "SEType_String",
    # 'SEType_Vector',
    # 'SEType_Struct',
    "SEType_WorldIntersection",
    "SEType_WorldIntersections",
    "SEType_WorldConeIntersections",
    "SEType_UserMarker",
)


class SEType_Vector(typing.Sequence[_VectorItemT]):
    pass


class SEType_Struct:
    def __init__(self) -> None:
        raise NotImplementedError()


@dataclasses.dataclass(frozen=True, kw_only=True)
class SEType_WorldIntersectionItem:
    world_point: SEType_Point3D
    object_point: SEType_Point3D
    object_name: SEType_String


SEType_WorldIntersection = typing.Optional[SEType_WorldIntersectionItem]

SEType_WorldIntersections = typing.NewType(
    "SEType_WorldIntersections", typing.Sequence[SEType_WorldIntersectionItem]
)


@dataclasses.dataclass(frozen=True, kw_only=True)
class SEType_WorldConeIntersectionItem:
    world_point: SEType_Point3D
    object_point: SEType_Point3D
    fraction_of_cone: SEType_f64
    object_name: SEType_String


SEType_WorldConeIntersections = typing.NewType(
    "SEType_WorldConeIntersections", typing.Sequence[SEType_WorldConeIntersectionItem]
)


@dataclasses.dataclass(frozen=True, kw_only=True)
class SEType_UserMarkerItem:
    error: SEType_s32
    camera_clock: SEType_u64
    camera_index: SEType_u8
    data: SEType_u64


SEType_UserMarker = typing.Optional[SEType_UserMarkerItem]


@dataclasses.dataclass(frozen=True, kw_only=True)
class SEType_PacketHeader:
    sync_id: SEType_u32
    packet_type: SEType_u16
    length: SEType_u16


@dataclasses.dataclass(frozen=True, kw_only=True)
class SEType_SubpacketHeader:
    id: SEType_u16
    length: SEType_u16


@dataclasses.dataclass(frozen=True, kw_only=True)
class SEType_Subpacket:
    header: SEType_SubpacketHeader
    data: typing.Optional[SEType_Any]
