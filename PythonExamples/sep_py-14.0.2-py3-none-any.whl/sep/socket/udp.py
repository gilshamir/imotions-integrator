import socket
from typing import Optional

from ..sepd import Packet, Parser

# Max theoretical size of a UDP packet.
_UDP_MAX_PACKET_SIZE = 2**16


class UDPClient:
    """UDPClient is a UDP client for Smart Eye Pro output data."""

    def __init__(
        self, host: str = "0.0.0.0", port: int = 5001, timeout: Optional[float] = 5.0
    ) -> None:
        self._host = host
        self._port = port
        self._sock_timeout = timeout

        self._sock: Optional[socket.socket] = None
        self._parser: Parser = Parser()

    def connect(self) -> None:
        self._sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        self._sock.settimeout(self._sock_timeout)
        self._sock.bind((self._host, self._port))

    def disconnect(self) -> None:
        if self._sock:
            self._sock.close()
        self._sock = None

    def receive(self) -> Packet:
        if not self._sock:
            raise RuntimeError("Trying to receive when not connected.")

        # Read a single UDP packet.
        bs = self._sock.recv(_UDP_MAX_PACKET_SIZE)

        # Parse as exactly one Packet.
        return self._parser.parse_packet(bs)
