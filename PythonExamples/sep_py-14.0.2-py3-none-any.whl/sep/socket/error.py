class EndOfStreamError(Exception):
    """Exception raised when stream has ended (remote end closed
    the connection)."""

    def __init__(self) -> None:
        super().__init__("End of stream")
