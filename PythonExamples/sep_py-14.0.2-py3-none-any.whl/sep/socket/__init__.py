"""Packet for receiving Smart Eye Pro data through TCP and UDP sockets."""

from .error import EndOfStreamError
from .tcp import TCPClient
from .udp import UDPClient

__all__ = ["TCPClient", "UDPClient", "EndOfStreamError"]
