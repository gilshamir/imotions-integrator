import socket
from typing import Optional

from ..sepd import Packet, Parser
from .error import EndOfStreamError

# The number of bytes we read each chunk from the socket. Fairly arbitrary, but
# it should be a power of 2.
_TCP_RECV_CHUNK_SIZE = 4096


class TCPClient:
    """TCPClient is a TCP client for Smart Eye Pro output data."""

    def __init__(
        self, host: str = "localhost", port: int = 5002, timeout: Optional[float] = 5.0
    ) -> None:
        self._host = host
        self._port = port
        self._sock_timeout = timeout

        self._sock: Optional[socket.socket] = None
        self._parser: Parser = Parser()
        self._packet_buffer: list[Packet] = []

    def _recv(self) -> None:
        if not self._sock:
            raise RuntimeError("Trying to receive when not connected.")

        # Read from socket in chunks. The Parser handles assembling the byte
        # stream into discrete Packets.
        bs = self._sock.recv(_TCP_RECV_CHUNK_SIZE)
        if not bs:
            raise EndOfStreamError()

        # Hand the bytes to the parser and store packets produced in our packet
        # buffer. Note that we cannot know if the bytes we have read will
        # result in 0, 1, or many packets here, as that requires parsing the
        # byte contents.
        packets = self._parser.parse_stream(bs)
        if packets:
            self._packet_buffer.extend(packets)

    def connect(self) -> None:
        self._sock = socket.create_connection(
            (self._host, self._port), self._sock_timeout
        )

    def disconnect(self) -> None:
        if self._sock:
            self._sock.close()
        self._sock = None
        self._packet_buffer.clear()

    def receive(self) -> Packet:
        # Read from socket until we have at least one full Packet.
        while not self._packet_buffer:
            self._recv()
        # Return oldest packet.
        return self._packet_buffer.pop(0)
