# Note: This file is generated from 'se_type_id.py.jinja2'!
import enum

@enum.unique
class SETypeId(enum.Enum):
    SEType_u8 = 0
    SEType_u16 = 1
    SEType_u32 = 2
    SEType_s32 = 3
    SEType_u64 = 4
    SEType_f64 = 5
    # SEType_float = 5
    SEType_Point2D = 6
    SEType_Vect2D = 7
    SEType_Point3D = 8
    SEType_Vect3D = 9
    SEType_String = 10
    SEType_Vector = 11
    SEType_Struct = 12
    SEType_WorldIntersection = 13
    SEType_WorldIntersections = 14
    SEType_PacketHeader = 15
    SEType_SubPacketHeader = 16
    SEType_f32 = 17
    SEType_Matrix3x3 = 18
    SEType_Matrix2x2 = 19
    SEType_Quaternion = 20
    SEType_UserMarker = 21
    SEType_PupilMatchPointAnalysis = 22
    SEType_WorldConeIntersections = 23
    SEType_WorldConeIntersection = 24
