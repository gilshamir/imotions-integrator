import ctypes
from typing import cast

from ..se_type_id import SETypeId
from ..se_types import (
    SEType_Any,
    SEType_f64,
    SEType_PacketHeader,
    SEType_Point2D,
    SEType_Point3D,
    SEType_Quaternion,
    SEType_s32,
    SEType_String,
    SEType_Subpacket,
    SEType_SubpacketHeader,
    SEType_u8,
    SEType_u16,
    SEType_u32,
    SEType_u64,
    SEType_UserMarker,
    SEType_UserMarkerItem,
    SEType_Vect2D,
    SEType_Vect3D,
    SEType_Vector,
    SEType_WorldIntersection,
    SEType_WorldIntersectionItem,
    SEType_WorldIntersections,
    SEType_WorldConeIntersections,
    SEType_WorldConeIntersectionItem,
)
from .error import (
    NotEnoughDataError,
    ParseError,
    UnknownOutputDataError,
    UnknownTypeError,
)
from .se_output_data import SEOutputDataId, output_data_type


class SEU8(ctypes.BigEndianStructure):
    _pack_ = 1
    _fields_ = [("value", ctypes.c_uint8)]


class SEU16(ctypes.BigEndianStructure):
    _pack_ = 1
    _fields_ = [("value", ctypes.c_uint16)]


class SEU32(ctypes.BigEndianStructure):
    _pack_ = 1
    _fields_ = [("value", ctypes.c_uint32)]


class SES32(ctypes.BigEndianStructure):
    _pack_ = 1
    _fields_ = [("value", ctypes.c_int32)]


class SEU64(ctypes.BigEndianStructure):
    _pack_ = 1
    _fields_ = [("value", ctypes.c_uint64)]


class SEF64(ctypes.BigEndianStructure):
    _pack_ = 1
    _fields_ = [("value", ctypes.c_double)]


SEU8Size = ctypes.sizeof(SEU8)
SEU16Size = ctypes.sizeof(SEU16)
SEU32Size = ctypes.sizeof(SEU32)
SES32Size = ctypes.sizeof(SES32)
SEU64Size = ctypes.sizeof(SEU64)
SEF64Size = ctypes.sizeof(SEF64)


def parse_any(bs: bytes, type_id: SETypeId) -> tuple[bytes, SEType_Any]:
    if type_id == SETypeId.SEType_u8:
        return parse_u8(bs)
    elif type_id == SETypeId.SEType_u16:
        return parse_u16(bs)
    elif type_id == SETypeId.SEType_u32:
        return parse_u32(bs)
    elif type_id == SETypeId.SEType_s32:
        return parse_s32(bs)
    elif type_id == SETypeId.SEType_u64:
        return parse_u64(bs)
    elif type_id == SETypeId.SEType_f64:
        return parse_f64(bs)
    elif type_id == SETypeId.SEType_Point2D:
        return parse_point2d(bs)
    elif type_id == SETypeId.SEType_Vect2D:
        return parse_vect2d(bs)
    elif type_id == SETypeId.SEType_Point3D:
        return parse_point3d(bs)
    elif type_id == SETypeId.SEType_Vect3D:
        return parse_vect3d(bs)
    elif type_id == SETypeId.SEType_Quaternion:
        return parse_quaternion(bs)
    elif type_id == SETypeId.SEType_String:
        return parse_string(bs)
    elif type_id == SETypeId.SEType_Vector:
        return parse_vector(bs)
    elif type_id == SETypeId.SEType_WorldIntersection:
        return parse_world_intersection(bs)
    elif type_id == SETypeId.SEType_WorldIntersections:
        return parse_world_intersections(bs)
    elif type_id == SETypeId.SEType_WorldConeIntersections:
        return parse_world_cone_intersections(bs)
    elif type_id == SETypeId.SEType_UserMarker:
        return parse_user_marker(bs)
    else:
        raise UnknownTypeError(type_id.value)


def parse_u8(bs: bytes) -> tuple[bytes, SEType_u8]:
    if len(bs) < SEU8Size:
        raise NotEnoughDataError()
    val = SEU8.from_buffer_copy(bs[:SEU8Size]).value
    return bs[SEU8Size:], SEType_u8(val)


def parse_u16(bs: bytes) -> tuple[bytes, SEType_u16]:
    if len(bs) < SEU16Size:
        raise NotEnoughDataError()
    val = SEU16.from_buffer_copy(bs[:SEU16Size]).value
    return bs[SEU16Size:], SEType_u16(val)


def parse_u32(bs: bytes) -> tuple[bytes, SEType_u32]:
    if len(bs) < SEU32Size:
        raise NotEnoughDataError()
    val = SEU32.from_buffer_copy(bs[:SEU32Size]).value
    return bs[SEU32Size:], SEType_u32(val)


def parse_s32(bs: bytes) -> tuple[bytes, SEType_s32]:
    if len(bs) < SES32Size:
        raise NotEnoughDataError()
    val = SES32.from_buffer_copy(bs[:SES32Size]).value
    return bs[SES32Size:], SEType_s32(val)


def parse_u64(bs: bytes) -> tuple[bytes, SEType_u64]:
    if len(bs) < SEU64Size:
        raise NotEnoughDataError()
    val = SEU64.from_buffer_copy(bs[:SEU64Size]).value
    return bs[SEU64Size:], SEType_u64(val)


def parse_f64(bs: bytes) -> tuple[bytes, SEType_f64]:
    if len(bs) < SEF64Size:
        raise NotEnoughDataError()
    val = SEF64.from_buffer_copy(bs[:SEF64Size]).value
    return bs[SEF64Size:], SEType_f64(val)


def parse_point2d(bs: bytes) -> tuple[bytes, SEType_Point2D]:
    bs, x = parse_f64(bs)
    bs, y = parse_f64(bs)
    return bs, SEType_Point2D(x, y)


def parse_point3d(bs: bytes) -> tuple[bytes, SEType_Point3D]:
    bs, x = parse_f64(bs)
    bs, y = parse_f64(bs)
    bs, z = parse_f64(bs)
    return bs, SEType_Point3D(x, y, z)


def parse_vect2d(bs: bytes) -> tuple[bytes, SEType_Vect2D]:
    bs, x = parse_f64(bs)
    bs, y = parse_f64(bs)
    return bs, SEType_Vect2D(x, y)


def parse_vect3d(bs: bytes) -> tuple[bytes, SEType_Vect3D]:
    bs, x = parse_f64(bs)
    bs, y = parse_f64(bs)
    bs, z = parse_f64(bs)
    return bs, SEType_Vect3D(x, y, z)


def parse_quaternion(bs: bytes) -> tuple[bytes, SEType_Quaternion]:
    bs, w = parse_f64(bs)
    bs, x = parse_f64(bs)
    bs, y = parse_f64(bs)
    bs, z = parse_f64(bs)
    return bs, SEType_Quaternion(w=w, x=x, y=y, z=z)


def parse_string(bs: bytes) -> tuple[bytes, SEType_String]:
    bs, length = parse_u16(bs)
    s = ""
    for _ in range(length):
        bs, ch = parse_u8(bs)
        s += chr(ch)
    return bs, SEType_String(s)


def parse_vector(bs: bytes) -> tuple[bytes, SEType_Vector]:
    bs, length = parse_u16(bs)
    items: list[SEType_Any] = []
    item_types: list[SETypeId] = []
    for _ in range(length):
        bs, type_id = parse_u16(bs)
        bs, item = parse_any(bs, SETypeId(type_id))
        items.append(item)
        item_types.append(SETypeId(type_id))

    # A sepd vector can contain items of more than one type, but in practice
    # all items are always the same type. Making this assumption makes the API
    # much more pleasant, but means we do also need to verify the assumption,
    # should it ever change in the future.
    if not all([t == item_types[0] for t in item_types]):
        raise ParseError("Found vector with multiple types")

    return bs, cast(SEType_Vector, items)


def _parse_world_intersection_item(
    bs: bytes,
) -> tuple[bytes, SEType_WorldIntersectionItem]:
    bs, world_point = parse_point3d(bs)
    bs, object_point = parse_point3d(bs)
    bs, object_name = parse_string(bs)
    item = SEType_WorldIntersectionItem(
        world_point=world_point, object_point=object_point, object_name=object_name
    )
    return bs, item


def _parse_world_cone_intersection_item(
    bs: bytes,
) -> tuple[bytes, SEType_WorldConeIntersectionItem]:
    bs, world_point = parse_point3d(bs)
    bs, object_point = parse_point3d(bs)
    bs, fraction_of_cone = parse_f64(bs)
    bs, object_name = parse_string(bs)
    item = SEType_WorldConeIntersectionItem(
        world_point=world_point,
        object_point=object_point,
        fraction_of_cone=fraction_of_cone,
        object_name=object_name,
    )
    return bs, item


def parse_world_intersection(bs: bytes) -> tuple[bytes, SEType_WorldIntersection]:
    bs, num_intersections = parse_u16(bs)
    if num_intersections == 0:
        return bs, None
    elif num_intersections == 1:
        return _parse_world_intersection_item(bs)
    else:
        raise ParseError("WorldIntersection.num_intersections != 0, 1")


def parse_world_intersections(bs: bytes) -> tuple[bytes, SEType_WorldIntersections]:
    bs, num_intersections = parse_u16(bs)
    intersections = []
    for _ in range(num_intersections):
        bs, item = _parse_world_intersection_item(bs)
        intersections.append(item)
    return bs, cast(SEType_WorldIntersections, intersections)


def parse_world_cone_intersections(
    bs: bytes,
) -> tuple[bytes, SEType_WorldConeIntersections]:
    bs, num_intersections = parse_u16(bs)
    intersections = []
    for _ in range(num_intersections):
        bs, item = _parse_world_cone_intersection_item(bs)
        intersections.append(item)
    return bs, cast(SEType_WorldConeIntersections, intersections)


def parse_user_marker(bs: bytes) -> tuple[bytes, SEType_UserMarker]:
    bs, exists = parse_u16(bs)
    if not exists:
        return bs, None
    bs, error = parse_s32(bs)
    bs, camera_clock = parse_u64(bs)
    bs, camera_index = parse_u8(bs)
    bs, data = parse_u64(bs)
    return bs, SEType_UserMarkerItem(
        error=error, camera_clock=camera_clock, camera_index=camera_index, data=data
    )


def parse_subpacket_header(bs: bytes) -> tuple[bytes, SEType_SubpacketHeader]:
    bs, id = parse_u16(bs)
    bs, length = parse_u16(bs)
    return bs, SEType_SubpacketHeader(id=id, length=length)


def _take_subpacket(bs: bytes, header: SEType_SubpacketHeader) -> tuple[bytes, bytes]:
    if len(bs) < header.length:
        raise NotEnoughDataError()
    bs, subpacket = bs[header.length :], bs[: header.length]
    return bs, subpacket


def parse_subpacket(bs: bytes) -> tuple[bytes, SEType_Subpacket]:
    bs, header = parse_subpacket_header(bs)
    # Try lookup SEOutputDataId given id from header.
    try:
        output_data_id = SEOutputDataId(header.id)
    except ValueError:
        raise UnknownOutputDataError(header.id)

    # Try lookup data type id for the output data id.
    output_data_id = SEOutputDataId(header.id)
    type_id = output_data_type(output_data_id)
    if type_id is None:
        raise UnknownOutputDataError(header.id)

    # Parse subpacket as data type. We expect a subpacket to be _exactly_ one
    # data type => parse_any should fully consume the subpacket.
    bs, subpacket = _take_subpacket(bs, header)
    subpacket, data = parse_any(subpacket, type_id)
    if subpacket:
        raise ParseError("Subpacket was not fully consumed.")

    return bs, SEType_Subpacket(header=header, data=data)


def skip_subpacket(bs: bytes) -> bytes:
    bs, header = parse_subpacket_header(bs)
    bs, _ = _take_subpacket(bs, header)
    return bs


def parse_packet_header(bs: bytes) -> tuple[bytes, SEType_PacketHeader]:
    bs, sync_id = parse_u32(bs)
    bs, packet_type = parse_u16(bs)
    bs, length = parse_u16(bs)
    return bs, SEType_PacketHeader(
        sync_id=sync_id, packet_type=packet_type, length=length
    )
