# Note: This file is generated from 'packet.py.jinja2'!
import warnings
from typing import Optional, cast

from ..se_types import (
    SEType_Any,
    SEType_u8,
    SEType_u16,
    SEType_u32,
    SEType_s32,
    SEType_u64,
    SEType_f64,
    SEType_Point2D,
    SEType_Point3D,
    SEType_Vect2D,
    SEType_Vect3D,
    SEType_Quaternion,
    SEType_String,
    SEType_Vector,
    SEType_WorldIntersection,
    SEType_WorldIntersections,
    SEType_WorldConeIntersections,
    SEType_UserMarker,
)

class Packet:
    def __init__(self, data: dict[SEType_u16, SEType_Any]):
        self._data = data

    def __get(self, key: int) -> SEType_Any:
        return self._data.get(SEType_u16(key))

    @property
    def frame_number(self) -> Optional[SEType_u32]:
        r"""A sequential frame number, set by the image capture subsystem. The frame number starts counting from 0 at application start and increments by +1 for each successfully captured image. This means that the frame number of two consecutive frames will always differ by 1 even if the image capture subsystem should happen to drop one or more frames in between. 
If the frame numbers in the data output should increment by more than +1 from one data record to the next, then it is either an indication of frame loss in the image processing subsystem, probably due to CPU overload or, in the case of UDP communication, loss of network data packets. 
If an image source error, such as an Ethernet cable temporarily loosing connection to its socket, occurs when Smart Eye Pro is running the frame numbering will restart from 0 to indicate that a problem has occurred. 
N.B: The frame number should not be used to detect frame loss. The only reliable way to determine frame loss is to check the time stamp difference between two consecutive data records."""
        return cast(Optional[SEType_u32], self.__get(0x0001))

    @property
    def estimated_delay(self) -> Optional[SEType_u32]:
        r"""The estimated delay from the real-world event (midpoint of image exposure for live cameras, or time of finished read when reading from file) to the network socket send() system call."""
        return cast(Optional[SEType_u32], self.__get(0x0002))

    @property
    def time_stamp(self) -> Optional[SEType_u64]:
        r"""A high-resolution time stamp, measured at the midpoint of image exposure and starting to count from 0 when the application is started. Since this time stamp is based on the PC hardware high-resolution clock, it should only be used to measure time differences over relatively short periods of time."""
        return cast(Optional[SEType_u64], self.__get(0x0003))

    @property
    def user_time_stamp(self) -> Optional[SEType_u64]:
        r"""64 bits of user defined information, usually an absolute-time time stamp and/or annotation data. The .dll generating this value has to follow the TimeService.h interface (See Chapter \ref{ChapterTimeSynchronizationSpecification} for detailed information)."""
        return cast(Optional[SEType_u64], self.__get(0x0004))

    @property
    def frame_rate(self) -> Optional[SEType_f64]:
        r"""The current frame rate of the system in frames. Should ideally be 60 or 120 frames per second depending on system configuration."""
        return cast(Optional[SEType_f64], self.__get(0x0005))

    @property
    def camera_positions(self) -> Optional[SEType_Vector[SEType_Point3D]]:
        r"""The position of all the cameras defined in the World Coordinate System."""
        return cast(Optional[SEType_Vector[SEType_Point3D]], self.__get(0x0006))

    @property
    def camera_rotations(self) -> Optional[SEType_Vector[SEType_Vect3D]]:
        r"""The rodrigues rotation of all the cameras defined in the World Coordinate System."""
        return cast(Optional[SEType_Vector[SEType_Vect3D]], self.__get(0x0007))

    @property
    def user_defined_data(self) -> Optional[SEType_u64]:
        r"""User defined data, not used at the moment."""
        return cast(Optional[SEType_u64], self.__get(0x0008))

    @property
    def real_time_clock(self) -> Optional[SEType_u64]:
        r"""The real time clock reads the computer clock and represents it as a 64-bit value in FILETIME format as an absolute time since January 1, 1601 (UTC)."""
        return cast(Optional[SEType_u64], self.__get(0x0009))

    @property
    def head_position(self) -> Optional[SEType_Point3D]:
        r"""The 3D head position in the defined World Coordinate System."""
        return cast(Optional[SEType_Point3D], self.__get(0x0010))

    @property
    def head_position_quality(self) -> Optional[SEType_f64]:
        r"""Quality of the head position [0..1]."""
        return cast(Optional[SEType_f64], self.__get(0x0011))

    @property
    def head_rotation_rodrigues(self) -> Optional[SEType_Vect3D]:
        r"""The 3D head orientation in Rodrigues format in the defined World Coordinate System."""
        return cast(Optional[SEType_Vect3D], self.__get(0x0012))

    @property
    def head_rotation_quaternion(self) -> Optional[SEType_Quaternion]:
        r"""The 3D head orientation as a quaternion in the defined World Coordinate System."""
        return cast(Optional[SEType_Quaternion], self.__get(0x001d))

    @property
    def head_left_ear_direction(self) -> Optional[SEType_Vect3D]:
        r"""Unit vector defining the 'left ear' direction. Identical to the x-axis of the head rotation matrix."""
        return cast(Optional[SEType_Vect3D], self.__get(0x0015))

    @property
    def head_up_direction(self) -> Optional[SEType_Vect3D]:
        r"""Unit vector defining the 'up' direction. Identical to the y-axis of the head rotation matrix."""
        return cast(Optional[SEType_Vect3D], self.__get(0x0014))

    @property
    def head_nose_direction(self) -> Optional[SEType_Vect3D]:
        r"""Unit vector defining the 'nose' direction. Identical to the z-axis of the head rotation matrix."""
        return cast(Optional[SEType_Vect3D], self.__get(0x0013))

    @property
    def head_heading(self) -> Optional[SEType_f64]:
        r"""The left/right-rotation of the head. Also known as "no"-rotation (See Section on "Definition of Euler Angles" in the \ProductName manual)."""
        return cast(Optional[SEType_f64], self.__get(0x0016))

    @property
    def head_pitch(self) -> Optional[SEType_f64]:
        r"""The up/down-rotation of the head. Also known as "yes"-rotation (See Section on "Definition of Euler Angles" in the \ProductName manual)."""
        return cast(Optional[SEType_f64], self.__get(0x0017))

    @property
    def head_roll(self) -> Optional[SEType_f64]:
        r"""The tilt-rotation of the head. Also known as "maybe"-rotation (See Section on "Definition of Euler Angles" in the \ProductName manual)."""
        return cast(Optional[SEType_f64], self.__get(0x0018))

    @property
    def head_rotation_quality(self) -> Optional[SEType_f64]:
        r"""Quality of the head orientation [0..1] (The same value as the head position quality)."""
        return cast(Optional[SEType_f64], self.__get(0x0019))

    @property
    def gaze_origin(self) -> Optional[SEType_Point3D]:
        r"""The consensus of the LeftGazeOrigin and RightGazeOrigin described as a virtual point located in the middle of the two origins, provided that both origins are available."""
        return cast(Optional[SEType_Point3D], self.__get(0x001a))

    @property
    def left_gaze_origin(self) -> Optional[SEType_Point3D]:
        r"""The center of the pupil/iris of the left eye, where the gaze vector originates."""
        return cast(Optional[SEType_Point3D], self.__get(0x001b))

    @property
    def right_gaze_origin(self) -> Optional[SEType_Point3D]:
        r"""The center of the pupil/iris of the right eye, where the gaze vector originates."""
        return cast(Optional[SEType_Point3D], self.__get(0x001c))

    @property
    def eye_position(self) -> Optional[SEType_Point3D]:
        r"""The virtual 3D eye position given in the defined World Coordinate System."""
        return cast(Optional[SEType_Point3D], self.__get(0x0020))

    @property
    def gaze_direction(self) -> Optional[SEType_Vect3D]:
        r"""A unit vector originating in the GazeOrigin describing the direction of the gaze. Calculated as the average direction of the two gaze vectors originating at the physical eyes. If vergence is of interest, the eyes should be handled separately instead."""
        return cast(Optional[SEType_Vect3D], self.__get(0x0021))

    @property
    def gaze_direction_quality(self) -> Optional[SEType_f64]:
        r"""Quality of the gaze direction measurement [0..1]. Depends on the quality of the pupil, iris and glint detection and the degree of agreement between measurements from different eye clips. Calculated as the maximum of the quality of the both physical eyes (see Section \ref{SubsectionGazeDirectionQuality})."""
        return cast(Optional[SEType_f64], self.__get(0x0022))

    @property
    def left_eye_position(self) -> Optional[SEType_Point3D]:
        r"""The 3D position of the center of the left eye ball given in the defined World Coordinate System."""
        return cast(Optional[SEType_Point3D], self.__get(0x0023))

    @property
    def left_gaze_direction(self) -> Optional[SEType_Vect3D]:
        r"""A unit vector describing the direction of the gaze of the left eye originating from the LeftGazeOrigin."""
        return cast(Optional[SEType_Vect3D], self.__get(0x0024))

    @property
    def left_gaze_direction_quality(self) -> Optional[SEType_f64]:
        r"""Quality of the left gaze direction measurement [0..1]. Depends on the quality of the pupil, iris and glint detection of the left eye and the degree of agreement between measurements from different eye clips for the left eye (see Section \ref{SubsectionGazeDirectionQuality})."""
        return cast(Optional[SEType_f64], self.__get(0x0025))

    @property
    def right_eye_position(self) -> Optional[SEType_Point3D]:
        r"""The 3D position of the center of the right eye ball given in the defined World Coordinate System."""
        return cast(Optional[SEType_Point3D], self.__get(0x0026))

    @property
    def right_gaze_direction(self) -> Optional[SEType_Vect3D]:
        r"""A unit vector describing the direction of the gaze of the right eye, originating from the RightGazeOrigin."""
        return cast(Optional[SEType_Vect3D], self.__get(0x0027))

    @property
    def right_gaze_direction_quality(self) -> Optional[SEType_f64]:
        r"""Quality of the right gaze direction measurement [0..1]. Depends on the quality of the pupil, iris and glint detection of the right eye and the degree of agreement between measurements from different eye clips for the right eye (see Section \ref{SubsectionGazeDirectionQuality})."""
        return cast(Optional[SEType_f64], self.__get(0x0028))

    @property
    def gaze_heading(self) -> Optional[SEType_f64]:
        r"""The left/right angle of the GazeDirection (See Section on "Definition of Euler Angles" in the \ProductName manual)."""
        return cast(Optional[SEType_f64], self.__get(0x0029))

    @property
    def gaze_pitch(self) -> Optional[SEType_f64]:
        r"""The up/down angle of the GazeDirection (See Section on "Definition of Euler Angles" in the \ProductName manual)."""
        return cast(Optional[SEType_f64], self.__get(0x002a))

    @property
    def left_gaze_heading(self) -> Optional[SEType_f64]:
        r"""The left/right angle of the LeftGazeDirection (See Section on "Definition of Euler Angles" in the \ProductName manual)."""
        return cast(Optional[SEType_f64], self.__get(0x002b))

    @property
    def left_gaze_pitch(self) -> Optional[SEType_f64]:
        r"""The up/down angle of the LeftGazeDirection (See Section on "Definition of Euler Angles" in the \ProductName manual)."""
        return cast(Optional[SEType_f64], self.__get(0x002c))

    @property
    def right_gaze_heading(self) -> Optional[SEType_f64]:
        r"""The left/right angle of the RightGazeDirection (See Section on "Definition of Euler Angles" in the \ProductName manual)."""
        return cast(Optional[SEType_f64], self.__get(0x002d))

    @property
    def right_gaze_pitch(self) -> Optional[SEType_f64]:
        r"""The up/down angle of the RightGazeDirection (See Section on "Definition of Euler Angles" in the \ProductName manual)."""
        return cast(Optional[SEType_f64], self.__get(0x002e))

    @property
    def filtered_gaze_direction(self) -> Optional[SEType_Vect3D]:
        r""""""
        return cast(Optional[SEType_Vect3D], self.__get(0x0030))

    @property
    def filtered_left_gaze_direction(self) -> Optional[SEType_Vect3D]:
        r""""""
        return cast(Optional[SEType_Vect3D], self.__get(0x0032))

    @property
    def filtered_right_gaze_direction(self) -> Optional[SEType_Vect3D]:
        r""""""
        return cast(Optional[SEType_Vect3D], self.__get(0x0034))

    @property
    def filtered_gaze_heading(self) -> Optional[SEType_f64]:
        r""""""
        return cast(Optional[SEType_f64], self.__get(0x0036))

    @property
    def filtered_gaze_pitch(self) -> Optional[SEType_f64]:
        r""""""
        return cast(Optional[SEType_f64], self.__get(0x0037))

    @property
    def filtered_left_gaze_heading(self) -> Optional[SEType_f64]:
        r""""""
        return cast(Optional[SEType_f64], self.__get(0x0038))

    @property
    def filtered_left_gaze_pitch(self) -> Optional[SEType_f64]:
        r""""""
        return cast(Optional[SEType_f64], self.__get(0x0039))

    @property
    def filtered_right_gaze_heading(self) -> Optional[SEType_f64]:
        r""""""
        return cast(Optional[SEType_f64], self.__get(0x003a))

    @property
    def filtered_right_gaze_pitch(self) -> Optional[SEType_f64]:
        r""""""
        return cast(Optional[SEType_f64], self.__get(0x003b))

    @property
    def filtered_gaze_origin(self) -> Optional[SEType_Point3D]:
        r"""The gaze origin to be used with FilteredGazeDirection to calculate filtered intersections."""
        return cast(Optional[SEType_Point3D], self.__get(0x0500))

    @property
    def filtered_left_gaze_origin(self) -> Optional[SEType_Point3D]:
        r"""The gaze origin to be used with FilteredLeftGazeDirection to calculate filtered intersections."""
        return cast(Optional[SEType_Point3D], self.__get(0x0501))

    @property
    def filtered_right_gaze_origin(self) -> Optional[SEType_Point3D]:
        r"""The gaze origin to be used with FilteredRightGazeDirection to calculate filtered intersections."""
        return cast(Optional[SEType_Point3D], self.__get(0x0502))

    @property
    def saccade(self) -> Optional[SEType_u32]:
        r"""When the saccade detection filter detects a saccade, this value will be a non-zero integer for the duration of the saccade. This integer increases for each saccade and can be seen as a unique saccade identifier."""
        return cast(Optional[SEType_u32], self.__get(0x003d))

    @property
    def fixation(self) -> Optional[SEType_u32]:
        r"""When the fixation detection filter detects a fixation, this value will be a non-zero integer for the duration of the fixation. This integer increases for each fixation and can be seen as a unique fixation identifier."""
        return cast(Optional[SEType_u32], self.__get(0x003e))

    @property
    def blink(self) -> Optional[SEType_u32]:
        r"""When the blink detection filter detects a blink, this value will be a non-zero integer for the duration of the blink. This integer increases for each blink and can be seen as a unique blink identifier."""
        return cast(Optional[SEType_u32], self.__get(0x003f))

    @property
    def closest_world_intersection(self) -> Optional[SEType_WorldIntersection]:
        r"""The closest gaze intersection with any of the world objects. The intersection information contains name of object, intersection point in world coordinates and intersection point in object coordinates. 
Each sub packet of this type starts with an integer indicating the number of world intersections contained in the sub packet. If there are no gaze intersections with world objects for the current frame this integer will be 0, otherwise 1."""
        return cast(Optional[SEType_WorldIntersection], self.__get(0x0040))

    @property
    def filtered_closest_world_intersection(self) -> Optional[SEType_WorldIntersection]:
        r""""""
        return cast(Optional[SEType_WorldIntersection], self.__get(0x0041))

    @property
    def all_world_intersections(self) -> Optional[SEType_WorldIntersections]:
        r"""Analogue to ClosestWorldIntersection, but it contains the whole list of intersected world objects. E.g., if the right window of a car is intersected it may be interesting to also find out if the right rear mirror is intersected. 
 As with ClosestWorldIntersections, each sub packet of this type starts with an integer indicating the number of world intersections contained in the sub packet. The difference is that in this case there may be any number of intersections."""
        return cast(Optional[SEType_WorldIntersections], self.__get(0x0042))

    @property
    def filtered_all_world_intersections(self) -> Optional[SEType_WorldIntersections]:
        r"""Analogue to FilteredClosestWorldIntersection, but it contains the whole list of intersected world objects. E.g., if the right window of a car is intersected it may be interesting to also find out if the right rear mirror is intersected.As with ClosestWorldIntersections, each sub packet of this type starts with an integer indi- cating the number of world intersections con- tained in the sub packet.  The difference is that in this case there may be any number of intersections."""
        return cast(Optional[SEType_WorldIntersections], self.__get(0x0043))

    @property
    def estimated_closest_world_intersection(self) -> Optional[SEType_WorldIntersection]:
        r"""The closest intersection of the estimated gaze vector with any of the world objects. The intersection information contains name of object, intersection point in world coordinates and intersection point in object coordinates. 
Each sub packet of this type starts with an integer indicating the number of world intersections contained in the sub packet. If there are no gaze intersections with world objects for the current frame this integer will be 0, otherwise 1."""
        warnings.warn("The SEEstimatedClosestWorldIntersection output is deprecated and may be removed in a future version.", FutureWarning)
        return cast(Optional[SEType_WorldIntersection], self.__get(0x0045))

    @property
    def estimated_all_world_intersections(self) -> Optional[SEType_WorldIntersections]:
        r"""Analogue to EstimatedClosestWorldIntersection, but it contains the whole list of intersected world objects. E.g., if the right window of a car is intersected it may be interesting to also find out if the right rear mirror is intersected. 
 As with ClosestWorldIntersections, each sub packet of this type starts with an integer indicating the number of world intersections contained in the sub packet. The difference is that in this case there may be any number of intersections."""
        warnings.warn("The SEEstimatedAllWorldIntersections output is deprecated and may be removed in a future version.", FutureWarning)
        return cast(Optional[SEType_WorldIntersections], self.__get(0x0046))

    @property
    def head_closest_world_intersection(self) -> Optional[SEType_WorldIntersection]:
        r"""The closest intersection of the head nose vector with any of the world objects. The intersection information contains name of object, intersection point in world coordinates and intersection point in object coordinates. 
Each sub packet of this type starts with an integer indicating the number of world intersections contained in the sub packet. If there are no gaze intersections with world objects for the current frame this integer will be 0, otherwise 1."""
        return cast(Optional[SEType_WorldIntersection], self.__get(0x0049))

    @property
    def head_all_world_intersections(self) -> Optional[SEType_WorldIntersections]:
        r"""Analogue to HeadClosestWorldIntersection, but it contains the whole list of intersected world objects. E.g., if the right window of a car is intersected it may be interesting to also find out if the right rear mirror is intersected. 
 As with ClosestWorldIntersections, each sub packet of this type starts with an integer indicating the number of world intersections contained in the sub packet. The difference is that in this case there may be any number of intersections."""
        return cast(Optional[SEType_WorldIntersections], self.__get(0x004a))

    @property
    def eyelid_opening(self) -> Optional[SEType_f64]:
        r"""The average distance between the eyelids of both eyes."""
        return cast(Optional[SEType_f64], self.__get(0x0050))

    @property
    def eyelid_opening_quality(self) -> Optional[SEType_f64]:
        r"""Normally in the range 0..1, some subjects may have values larger than 1.0. The value depends on how distinct the eyelids can be detected. The range is individual and can not be compared between subjects. Calculates as the average quality of the both physical eyes."""
        return cast(Optional[SEType_f64], self.__get(0x0051))

    @property
    def left_eyelid_opening(self) -> Optional[SEType_f64]:
        r"""The distance between the eyelids of the left eye."""
        return cast(Optional[SEType_f64], self.__get(0x0052))

    @property
    def left_eyelid_opening_quality(self) -> Optional[SEType_f64]:
        r"""Quality of left eyelid detection (See description for EyelidOpeningQ)."""
        return cast(Optional[SEType_f64], self.__get(0x0053))

    @property
    def right_eyelid_opening(self) -> Optional[SEType_f64]:
        r"""The distance between the eyelids of the right eye."""
        return cast(Optional[SEType_f64], self.__get(0x0054))

    @property
    def right_eyelid_opening_quality(self) -> Optional[SEType_f64]:
        r"""Quality of right eyelid detection (See description for EyelidOpeningQ)."""
        return cast(Optional[SEType_f64], self.__get(0x0055))

    @property
    def keyboard_state(self) -> Optional[SEType_String]:
        r"""The keys that are currently pressed (A-Z, 0-9), useful for marking events in log files or movie recordings. Please note that due to limitations in a normal PC-keyboard, pressing more than two keys at a time gives undefined output."""
        return cast(Optional[SEType_String], self.__get(0x0056))

    @property
    def pupil_diameter(self) -> Optional[SEType_f64]:
        r"""The consensus diameter of the pupils of both eyes."""
        return cast(Optional[SEType_f64], self.__get(0x0060))

    @property
    def pupil_diameter_quality(self) -> Optional[SEType_f64]:
        r"""The quality value for the PupilDiameter. The value depends on how distinct the pupil/iris edge can be detected. The value is normalized and will be in the range of [0.0, 1.0]."""
        return cast(Optional[SEType_f64], self.__get(0x0061))

    @property
    def left_pupil_diameter(self) -> Optional[SEType_f64]:
        r"""The diameter of the pupil of the left eye."""
        return cast(Optional[SEType_f64], self.__get(0x0062))

    @property
    def left_pupil_diameter_quality(self) -> Optional[SEType_f64]:
        r"""The quality value for the LeftPupilDiameter. The value depends on how distinct the pupil/iris edge can be detected. The value is normalized and will be in the range of [0.0, 1.0]."""
        return cast(Optional[SEType_f64], self.__get(0x0063))

    @property
    def right_pupil_diameter(self) -> Optional[SEType_f64]:
        r"""The diameter of the pupil of the right eye."""
        return cast(Optional[SEType_f64], self.__get(0x0064))

    @property
    def right_pupil_diameter_quality(self) -> Optional[SEType_f64]:
        r"""The quality value for the RightPupilDiameter. The value depends on how distinct the pupil/iris edge can be detected. The value is normalized and will be in the range of [0.0, 1.0]."""
        return cast(Optional[SEType_f64], self.__get(0x0065))

    @property
    def filtered_pupil_diameter(self) -> Optional[SEType_f64]:
        r""""""
        return cast(Optional[SEType_f64], self.__get(0x0066))

    @property
    def filtered_pupil_diameter_quality(self) -> Optional[SEType_f64]:
        r""""""
        return cast(Optional[SEType_f64], self.__get(0x0067))

    @property
    def filtered_left_pupil_diameter(self) -> Optional[SEType_f64]:
        r""""""
        return cast(Optional[SEType_f64], self.__get(0x0068))

    @property
    def filtered_left_pupil_diameter_quality(self) -> Optional[SEType_f64]:
        r""""""
        return cast(Optional[SEType_f64], self.__get(0x0069))

    @property
    def filtered_right_pupil_diameter(self) -> Optional[SEType_f64]:
        r""""""
        return cast(Optional[SEType_f64], self.__get(0x006a))

    @property
    def filtered_right_pupil_diameter_quality(self) -> Optional[SEType_f64]:
        r""""""
        return cast(Optional[SEType_f64], self.__get(0x006b))

    @property
    def gps_position(self) -> Optional[SEType_Point2D]:
        r""""""
        return cast(Optional[SEType_Point2D], self.__get(0x0070))

    @property
    def gps_ground_speed(self) -> Optional[SEType_f64]:
        r""""""
        return cast(Optional[SEType_f64], self.__get(0x0071))

    @property
    def gps_course(self) -> Optional[SEType_f64]:
        r""""""
        return cast(Optional[SEType_f64], self.__get(0x0072))

    @property
    def gps_time(self) -> Optional[SEType_u64]:
        r""""""
        return cast(Optional[SEType_u64], self.__get(0x0073))

    @property
    def estimated_gaze_origin(self) -> Optional[SEType_Point3D]:
        r"""The calculation of the estimated gaze is based on the estimated eye center as obtained from head tracking. Its origin is the pupil or iris."""
        warnings.warn("The SEEstimatedGazeOrigin output is deprecated and may be removed in a future version.", FutureWarning)
        return cast(Optional[SEType_Point3D], self.__get(0x007a))

    @property
    def estimated_left_gaze_origin(self) -> Optional[SEType_Point3D]:
        r"""The calculation of the estimated gaze is based on the estimated eye center as obtained from head tracking. Its origin is the pupil or iris."""
        warnings.warn("The SEEstimatedLeftGazeOrigin output is deprecated and may be removed in a future version.", FutureWarning)
        return cast(Optional[SEType_Point3D], self.__get(0x007b))

    @property
    def estimated_right_gaze_origin(self) -> Optional[SEType_Point3D]:
        r"""The calculation of the estimated gaze is based on the estimated eye center as obtained from head tracking. Its origin is the pupil or iris."""
        warnings.warn("The SEEstimatedRightGazeOrigin output is deprecated and may be removed in a future version.", FutureWarning)
        return cast(Optional[SEType_Point3D], self.__get(0x007c))

    @property
    def estimated_eye_position(self) -> Optional[SEType_Point3D]:
        r"""The position of the consensus eye as obtained from head tracking."""
        warnings.warn("The SEEstimatedEyePosition output is deprecated and may be removed in a future version.", FutureWarning)
        return cast(Optional[SEType_Point3D], self.__get(0x0080))

    @property
    def estimated_gaze_direction(self) -> Optional[SEType_Vect3D]:
        r"""The calculation of the estimated gaze is based on the estimated eye center as obtained from head tracking. This is the direction is the vector from estimated eye center to pupil or iris."""
        warnings.warn("The SEEstimatedGazeDirection output is deprecated and may be removed in a future version.", FutureWarning)
        return cast(Optional[SEType_Vect3D], self.__get(0x0081))

    @property
    def estimated_gaze_direction_quality(self) -> Optional[SEType_f64]:
        r"""The calculation of the estimated gaze is based on the estimated eye center as obtained from head tracking. The gaze direction quality depends on how distinct the pupil/iris can be detected and how well gaze measurements from different eye clips coincide."""
        warnings.warn("The SEEstimatedGazeDirectionQ output is deprecated and may be removed in a future version.", FutureWarning)
        return cast(Optional[SEType_f64], self.__get(0x0082))

    @property
    def estimated_gaze_heading(self) -> Optional[SEType_f64]:
        r"""The heading angle of the estimated consensus gaze direction. (See Section on "Definition of Euler Angles" in the \ProductName manual)."""
        warnings.warn("The SEEstimatedGazeHeading output is deprecated and may be removed in a future version.", FutureWarning)
        return cast(Optional[SEType_f64], self.__get(0x0083))

    @property
    def estimated_gaze_pitch(self) -> Optional[SEType_f64]:
        r"""The pitch angle of the estimated consensus gaze direction. (See Section on "Definition of Euler Angles" in the \ProductName manual)."""
        warnings.warn("The SEEstimatedGazePitch output is deprecated and may be removed in a future version.", FutureWarning)
        return cast(Optional[SEType_f64], self.__get(0x0084))

    @property
    def estimated_left_eye_position(self) -> Optional[SEType_Point3D]:
        r"""The position of the left eye as obtained from head tracking."""
        warnings.warn("The SEEstimatedLeftEyePosition output is deprecated and may be removed in a future version.", FutureWarning)
        return cast(Optional[SEType_Point3D], self.__get(0x0085))

    @property
    def estimated_left_gaze_direction(self) -> Optional[SEType_Vect3D]:
        r"""The calculation of the estimated gaze is based on the estimated eye center as obtained from head tracking. This is the normalized vector from the left estimated eye center to pupil or iris."""
        warnings.warn("The SEEstimatedLeftGazeDirection output is deprecated and may be removed in a future version.", FutureWarning)
        return cast(Optional[SEType_Vect3D], self.__get(0x0086))

    @property
    def estimated_left_gaze_direction_quality(self) -> Optional[SEType_f64]:
        r"""The calculation of the estimated gaze is based on the estimated eye center as obtained from head tracking. The gaze direction quality depends on how distinct the pupil/iris can be detected and how well gaze measurements from several left eye clips coincide."""
        warnings.warn("The SEEstimatedLeftGazeDirectionQ output is deprecated and may be removed in a future version.", FutureWarning)
        return cast(Optional[SEType_f64], self.__get(0x0087))

    @property
    def estimated_left_gaze_heading(self) -> Optional[SEType_f64]:
        r"""The heading angle of the estimated left gaze direction. (See Section on "Definition of Euler Angles" in the \ProductName manual)."""
        warnings.warn("The SEEstimatedLeftGazeHeading output is deprecated and may be removed in a future version.", FutureWarning)
        return cast(Optional[SEType_f64], self.__get(0x0088))

    @property
    def estimated_left_gaze_pitch(self) -> Optional[SEType_f64]:
        r"""The pitch angle of the estimated left gaze direction. (See Section on "Definition of Euler Angles" in the \ProductName manual)."""
        warnings.warn("The SEEstimatedLeftGazePitch output is deprecated and may be removed in a future version.", FutureWarning)
        return cast(Optional[SEType_f64], self.__get(0x0089))

    @property
    def estimated_right_eye_position(self) -> Optional[SEType_Point3D]:
        r"""The position of the right eye as obtained from head tracking."""
        warnings.warn("The SEEstimatedRightEyePosition output is deprecated and may be removed in a future version.", FutureWarning)
        return cast(Optional[SEType_Point3D], self.__get(0x008a))

    @property
    def estimated_right_gaze_direction(self) -> Optional[SEType_Vect3D]:
        r"""The calculation of the estimated gaze is based on the estimated eye center as obtained from head tracking. This is the normalized vector from the right estimated eye center to pupil or iris."""
        warnings.warn("The SEEstimatedRightGazeDirection output is deprecated and may be removed in a future version.", FutureWarning)
        return cast(Optional[SEType_Vect3D], self.__get(0x008b))

    @property
    def estimated_right_gaze_direction_quality(self) -> Optional[SEType_f64]:
        r"""The calculation of the estimated gaze is based on the estimated eye center as obtained from head tracking. The gaze direction quality depends on how distinct the pupil/iris can be detected and how well gaze measurements from several right eye clips coincide."""
        warnings.warn("The SEEstimatedRightGazeDirectionQ output is deprecated and may be removed in a future version.", FutureWarning)
        return cast(Optional[SEType_f64], self.__get(0x008c))

    @property
    def estimated_right_gaze_heading(self) -> Optional[SEType_f64]:
        r"""The heading angle of the estimated right gaze direction. (See Section on "Definition of Euler Angles" in the \ProductName manual)."""
        warnings.warn("The SEEstimatedRightGazeHeading output is deprecated and may be removed in a future version.", FutureWarning)
        return cast(Optional[SEType_f64], self.__get(0x008d))

    @property
    def estimated_right_gaze_pitch(self) -> Optional[SEType_f64]:
        r"""The pitch angle of the estimated right gaze direction. (See Section on "Definition of Euler Angles" in the \ProductName manual)."""
        warnings.warn("The SEEstimatedRightGazePitch output is deprecated and may be removed in a future version.", FutureWarning)
        return cast(Optional[SEType_f64], self.__get(0x008e))

    @property
    def filtered_estimated_gaze_direction(self) -> Optional[SEType_Vect3D]:
        r""""""
        warnings.warn("The SEFilteredEstimatedGazeDirection output is deprecated and may be removed in a future version.", FutureWarning)
        return cast(Optional[SEType_Vect3D], self.__get(0x0091))

    @property
    def filtered_estimated_gaze_direction_quality(self) -> Optional[SEType_f64]:
        r""""""
        warnings.warn("The SEFilteredEstimatedGazeDirectionQ output is deprecated and may be removed in a future version.", FutureWarning)
        return cast(Optional[SEType_f64], self.__get(0x0092))

    @property
    def filtered_estimated_gaze_heading(self) -> Optional[SEType_f64]:
        r""""""
        warnings.warn("The SEFilteredEstimatedGazeHeading output is deprecated and may be removed in a future version.", FutureWarning)
        return cast(Optional[SEType_f64], self.__get(0x0093))

    @property
    def filtered_estimated_gaze_pitch(self) -> Optional[SEType_f64]:
        r""""""
        warnings.warn("The SEFilteredEstimatedGazePitch output is deprecated and may be removed in a future version.", FutureWarning)
        return cast(Optional[SEType_f64], self.__get(0x0094))

    @property
    def filtered_estimated_left_gaze_direction(self) -> Optional[SEType_Vect3D]:
        r""""""
        warnings.warn("The SEFilteredEstimatedLeftGazeDirection output is deprecated and may be removed in a future version.", FutureWarning)
        return cast(Optional[SEType_Vect3D], self.__get(0x0096))

    @property
    def filtered_estimated_left_gaze_direction_quality(self) -> Optional[SEType_f64]:
        r""""""
        warnings.warn("The SEFilteredEstimatedLeftGazeDirectionQ output is deprecated and may be removed in a future version.", FutureWarning)
        return cast(Optional[SEType_f64], self.__get(0x0097))

    @property
    def filtered_estimated_left_gaze_heading(self) -> Optional[SEType_f64]:
        r""""""
        warnings.warn("The SEFilteredEstimatedLeftGazeHeading output is deprecated and may be removed in a future version.", FutureWarning)
        return cast(Optional[SEType_f64], self.__get(0x0098))

    @property
    def filtered_estimated_left_gaze_pitch(self) -> Optional[SEType_f64]:
        r""""""
        warnings.warn("The SEFilteredEstimatedLeftGazePitch output is deprecated and may be removed in a future version.", FutureWarning)
        return cast(Optional[SEType_f64], self.__get(0x0099))

    @property
    def filtered_estimated_right_gaze_direction(self) -> Optional[SEType_Vect3D]:
        r""""""
        warnings.warn("The SEFilteredEstimatedRightGazeDirection output is deprecated and may be removed in a future version.", FutureWarning)
        return cast(Optional[SEType_Vect3D], self.__get(0x009b))

    @property
    def filtered_estimated_right_gaze_direction_quality(self) -> Optional[SEType_f64]:
        r""""""
        warnings.warn("The SEFilteredEstimatedRightGazeDirectionQ output is deprecated and may be removed in a future version.", FutureWarning)
        return cast(Optional[SEType_f64], self.__get(0x009c))

    @property
    def filtered_estimated_right_gaze_heading(self) -> Optional[SEType_f64]:
        r""""""
        warnings.warn("The SEFilteredEstimatedRightGazeHeading output is deprecated and may be removed in a future version.", FutureWarning)
        return cast(Optional[SEType_f64], self.__get(0x009d))

    @property
    def filtered_estimated_right_gaze_pitch(self) -> Optional[SEType_f64]:
        r""""""
        warnings.warn("The SEFilteredEstimatedRightGazePitch output is deprecated and may be removed in a future version.", FutureWarning)
        return cast(Optional[SEType_f64], self.__get(0x009e))

    @property
    def ascii_keyboard_state(self) -> Optional[SEType_u16]:
        r"""The ASCII code of the pressed key as an integer."""
        return cast(Optional[SEType_u16], self.__get(0x00a4))

    @property
    def calibration_gaze_intersection(self) -> Optional[SEType_WorldIntersection]:
        r"""Only used to send the selected calibration object to clients. Useful if a calibration point shall be displayed on a screen when performing the gaze calibration."""
        return cast(Optional[SEType_WorldIntersection], self.__get(0x00b0))

    @property
    def tagged_gaze_intersection(self) -> Optional[SEType_WorldIntersection]:
        r"""The position of the current gaze target. It contains the name of the object, the position in world coordinates and the position in object coordinates."""
        return cast(Optional[SEType_WorldIntersection], self.__get(0x00b1))

    @property
    def left_closest_world_intersection(self) -> Optional[SEType_WorldIntersection]:
        r"""The closest intersection of the left eye gaze vector with any of the world objects. The intersection information contains name of object, intersection point in world coordinates and intersection point in object coordinates. 
Each sub packet of this type starts with an integer indicating the number of world intersections contained in the sub packet. If there are no gaze intersections with world objects for the current frame this integer will be 0, otherwise 1."""
        return cast(Optional[SEType_WorldIntersection], self.__get(0x00b2))

    @property
    def left_all_world_intersections(self) -> Optional[SEType_WorldIntersections]:
        r"""Analogue to LeftClosestWorldIntersection, but it contains the whole list of intersected world objects. E.g., if the right window of a car is intersected it may be interesting to also find out if the right rear mirror is intersected. 
 As with LeftClosestWorldIntersection, each sub packet of this type starts with an integer indicating the number of world intersections contained in the sub packet. The difference is that in this case there may be any number of intersections."""
        return cast(Optional[SEType_WorldIntersections], self.__get(0x00b3))

    @property
    def right_closest_world_intersection(self) -> Optional[SEType_WorldIntersection]:
        r"""The closest intersection of the right eye gaze vector with any of the world objects. The intersection information contains name of object, intersection point in world coordinates and intersection point in object coordinates. 
Each sub packet of this type starts with an integer indicating the number of world intersections contained in the sub packet. If there are no gaze intersections with world objects for the current frame this integer will be 0, otherwise 1."""
        return cast(Optional[SEType_WorldIntersection], self.__get(0x00b4))

    @property
    def right_all_world_intersections(self) -> Optional[SEType_WorldIntersections]:
        r"""Analogue to RightClosestWorldIntersection, but it contains the whole list of intersected world objects. E.g., if the right window of a car is intersected it may be interesting to also find out if the right rear mirror is intersected. 
 As with RightClosestWorldIntersection, each sub packet of this type starts with an integer indicating the number of world intersections contained in the sub packet. The difference is that in this case there may be any number of intersections."""
        return cast(Optional[SEType_WorldIntersections], self.__get(0x00b5))

    @property
    def filtered_left_closest_world_intersection(self) -> Optional[SEType_WorldIntersection]:
        r"""The closest intersection of the filtered left gaze vector with any of the world objects. The intersection information contains name of object, intersection point in world coordinates and intersection point in object coordinates. 
Each sub packet of this type starts with an integer indicating the number of world intersections contained in the sub packet. If there are no gaze intersections with world objects for the current frame this integer will be 0, otherwise 1."""
        return cast(Optional[SEType_WorldIntersection], self.__get(0x00b6))

    @property
    def filtered_left_all_world_intersections(self) -> Optional[SEType_WorldIntersections]:
        r"""Analogue to FilteredLeftClosestWorldIntersection, but it contains the whole list of intersected world objects. E.g., if the right window of a car is intersected it may be interesting to also find out if the right rear mirror is intersected.As with ClosestWorldIntersections, each sub packet of this type starts with an integer indicating the number of world intersections contained in the sub packet. The difference is that in this case there may be any number of intersections."""
        return cast(Optional[SEType_WorldIntersections], self.__get(0x00b7))

    @property
    def filtered_right_closest_world_intersection(self) -> Optional[SEType_WorldIntersection]:
        r"""The closest intersection of the filtered right gaze vector with any of the world objects. The intersection information contains name of object, intersection point in world coordinates and intersection point in object coordinates. 
Each sub packet of this type starts with an integer indicating the number of world intersections contained in the sub packet. If there are no gaze intersections with world objects for the current frame this integer will be 0, otherwise 1."""
        return cast(Optional[SEType_WorldIntersection], self.__get(0x00b8))

    @property
    def filtered_right_all_world_intersections(self) -> Optional[SEType_WorldIntersections]:
        r"""Analogue to FilteredRightClosestWorldIntersection, but it contains the whole list of intersected world objects. E.g., if the right window of a car is intersected it may be interesting to also find out if the right rear mirror is intersected.As with ClosestWorldIntersections, each sub packet of this type starts with an integer indicating the number of world intersections contained in the sub packet. The difference is that in this case there may be any number of intersections."""
        return cast(Optional[SEType_WorldIntersections], self.__get(0x00b9))

    @property
    def estimated_left_closest_world_intersection(self) -> Optional[SEType_WorldIntersection]:
        r"""The closest intersection of the estimated left gaze vector with any of the world objects. The intersection information contains name of object, intersection point in world coordinates and intersection point in object coordinates. 
Each sub packet of this type starts with an integer indicating the number of world intersections contained in the sub packet. If there are no gaze intersections with world objects for the current frame this integer will be 0, otherwise 1."""
        warnings.warn("The SEEstimatedLeftClosestWorldIntersection output is deprecated and may be removed in a future version.", FutureWarning)
        return cast(Optional[SEType_WorldIntersection], self.__get(0x00ba))

    @property
    def estimated_left_all_world_intersections(self) -> Optional[SEType_WorldIntersections]:
        r"""Analogue to EstimatedLeftClosestWorldIntersection, but it contains the whole list of intersected world objects. E.g., if the right window of a car is intersected it may be interesting to also find out if the right rear mirror is intersected. 
 As with ClosestWorldIntersections, each sub packet of this type starts with an integer indicating the number of world intersections contained in the sub packet. The difference is that in this case there may be any number of intersections."""
        warnings.warn("The SEEstimatedLeftAllWorldIntersections output is deprecated and may be removed in a future version.", FutureWarning)
        return cast(Optional[SEType_WorldIntersections], self.__get(0x00bb))

    @property
    def estimated_right_closest_world_intersection(self) -> Optional[SEType_WorldIntersection]:
        r"""The closest intersection of the estimated right gaze vector with any of the world objects. The intersection information contains name of object, intersection point in world coordinates and intersection point in object coordinates. 
Each sub packet of this type starts with an integer indicating the number of world intersections contained in the sub packet. If there are no gaze intersections with world objects for the current frame this integer will be 0, otherwise 1."""
        warnings.warn("The SEEstimatedRightClosestWorldIntersection output is deprecated and may be removed in a future version.", FutureWarning)
        return cast(Optional[SEType_WorldIntersection], self.__get(0x00bc))

    @property
    def estimated_right_all_world_intersections(self) -> Optional[SEType_WorldIntersections]:
        r"""Analogue to EstimatedRightClosestWorldIntersection, but it contains the whole list of intersected world objects. E.g., if the right window of a car is intersected it may be interesting to also find out if the right rear mirror is intersected. 
 As with ClosestWorldIntersections, each sub packet of this type starts with an integer indicating the number of world intersections contained in the sub packet. The difference is that in this case there may be any number of intersections."""
        warnings.warn("The SEEstimatedRightAllWorldIntersections output is deprecated and may be removed in a future version.", FutureWarning)
        return cast(Optional[SEType_WorldIntersections], self.__get(0x00bd))

    @property
    def filtered_estimated_closest_world_intersection(self) -> Optional[SEType_WorldIntersection]:
        r""""""
        warnings.warn("The SEFilteredEstimatedClosestWorldIntersection output is deprecated and may be removed in a future version.", FutureWarning)
        return cast(Optional[SEType_WorldIntersection], self.__get(0x0141))

    @property
    def filtered_estimated_all_world_intersections(self) -> Optional[SEType_WorldIntersections]:
        r"""Analogue to FilteredEstimatedClosestWorldIntersection, but it contains the whole list of intersected world objects. E.g., if the right window of a car is intersected it may be interesting to also find out if the right rear mirror is intersected. As with ClosestWorldIntersections, each sub packet of this type starts with an integer indicating the number of world intersections contained in the sub packet. The difference is that in this case there may be any number of intersections."""
        warnings.warn("The SEFilteredEstimatedAllWorldIntersections output is deprecated and may be removed in a future version.", FutureWarning)
        return cast(Optional[SEType_WorldIntersections], self.__get(0x0143))

    @property
    def filtered_estimated_left_closest_world_intersection(self) -> Optional[SEType_WorldIntersection]:
        r"""The closest intersection of the filtered estimated left gaze vector with any of the world objects. The intersection information contains name of object, intersection point in world coordinates and intersection point in object coordinates. 
Each sub packet of this type starts with an integer indicating the number of world intersections contained in the sub packet. If there are no gaze intersections with world objects for the current frame this integer will be 0, otherwise 1."""
        warnings.warn("The SEFilteredEstimatedLeftClosestWorldIntersection output is deprecated and may be removed in a future version.", FutureWarning)
        return cast(Optional[SEType_WorldIntersection], self.__get(0x01b6))

    @property
    def filtered_estimated_left_all_world_intersections(self) -> Optional[SEType_WorldIntersections]:
        r"""Analogue to FilteredEstimatedLeftClosestWorldIntersection, but it contains the whole list of intersected world objects. E.g., if the right window of a car is intersected it may be interesting to also find out if the right rear mirror is intersected. As with ClosestWorldIntersections, each sub packet of this type starts with an integer indicating the number of world intersections contained in the sub packet. The difference is that in this case there may be any number of intersections."""
        warnings.warn("The SEFilteredEstimatedLeftAllWorldIntersections output is deprecated and may be removed in a future version.", FutureWarning)
        return cast(Optional[SEType_WorldIntersections], self.__get(0x01b7))

    @property
    def filtered_estimated_right_closest_world_intersection(self) -> Optional[SEType_WorldIntersection]:
        r"""The closest intersection of the filtered sstimated right gaze vector with any of the world objects. The intersection information contains name of object, intersection point in world coordinates and intersection point in object coordinates. 
Each sub packet of this type starts with an integer indicating the number of world intersections contained in the sub packet. If there are no gaze intersections with world objects for the current frame this integer will be 0, otherwise 1."""
        warnings.warn("The SEFilteredEstimatedRightClosestWorldIntersection output is deprecated and may be removed in a future version.", FutureWarning)
        return cast(Optional[SEType_WorldIntersection], self.__get(0x01b8))

    @property
    def filtered_estimated_right_all_world_intersections(self) -> Optional[SEType_WorldIntersections]:
        r"""Analogue to FilteredEstimatedRightClosestWorldIntersection, but it contains the whole list of intersected world objects. E.g., if the right window of a car is intersected it may be interesting to also find out if the right rear mirror is intersected. As with ClosestWorldIntersections, each sub packet of this type starts with an integer indicating the number of world intersections contained in the sub packet. The difference is that in this case there may be any number of intersections."""
        warnings.warn("The SEFilteredEstimatedRightAllWorldIntersections output is deprecated and may be removed in a future version.", FutureWarning)
        return cast(Optional[SEType_WorldIntersections], self.__get(0x01b9))

    @property
    def all_world_cone_intersections(self) -> Optional[SEType_WorldConeIntersections]:
        r"""Contains list of world objects which are within the gaze cone. Each object intersected is outputted as follows: world position, object position, the fraction of the total amount of rays from the cone intersecting the object, name of the object."""
        return cast(Optional[SEType_WorldConeIntersections], self.__get(0x01ba))

    @property
    def left_all_world_cone_intersections(self) -> Optional[SEType_WorldConeIntersections]:
        r"""Contains list of world objects which are within the gaze cone. Each object intersected is outputted as follows: world position, object position, the fraction of the total amount of rays from the cone intersecting the object, name of the object."""
        return cast(Optional[SEType_WorldConeIntersections], self.__get(0x01bb))

    @property
    def right_all_world_cone_intersections(self) -> Optional[SEType_WorldConeIntersections]:
        r"""Contains list of world objects which are within the gaze cone. Each object intersected is outputted as follows: world position, object position, the fraction of the total amount of rays from the cone intersecting the object, name of the object."""
        return cast(Optional[SEType_WorldConeIntersections], self.__get(0x01bc))

    @property
    def filtered_all_world_cone_intersections(self) -> Optional[SEType_WorldConeIntersections]:
        r"""Contains list of world objects which are within the gaze cone. Each object intersected is outputted as follows: world position, object position, the fraction of the total amount of rays from the cone intersecting the object, name of the object."""
        return cast(Optional[SEType_WorldConeIntersections], self.__get(0x01bd))

    @property
    def filtered_left_all_world_cone_intersections(self) -> Optional[SEType_WorldConeIntersections]:
        r"""Contains list of world objects which are within the gaze cone. Each object intersected is outputted as follows: world position, object position, the fraction of the total amount of rays from the cone intersecting the object, name of the object."""
        return cast(Optional[SEType_WorldConeIntersections], self.__get(0x01be))

    @property
    def filtered_right_all_world_cone_intersections(self) -> Optional[SEType_WorldConeIntersections]:
        r"""Contains list of world objects which are within the gaze cone. Each object intersected is outputted as follows: world position, object position, the fraction of the total amount of rays from the cone intersecting the object, name of the object."""
        return cast(Optional[SEType_WorldConeIntersections], self.__get(0x01bf))

    @property
    def left_blink_closing_mid_time(self) -> Optional[SEType_u64]:
        r"""See Section \ref{sec:blinks}."""
        return cast(Optional[SEType_u64], self.__get(0x00e0))

    @property
    def left_blink_opening_mid_time(self) -> Optional[SEType_u64]:
        r"""See Section \ref{sec:blinks}."""
        return cast(Optional[SEType_u64], self.__get(0x00e1))

    @property
    def left_blink_closing_amplitude(self) -> Optional[SEType_f64]:
        r"""See Section \ref{sec:blinks}."""
        return cast(Optional[SEType_f64], self.__get(0x00e2))

    @property
    def left_blink_opening_amplitude(self) -> Optional[SEType_f64]:
        r"""See Section \ref{sec:blinks}."""
        return cast(Optional[SEType_f64], self.__get(0x00e3))

    @property
    def left_blink_closing_speed(self) -> Optional[SEType_f64]:
        r"""See Section \ref{sec:blinks}."""
        return cast(Optional[SEType_f64], self.__get(0x00e4))

    @property
    def left_blink_opening_speed(self) -> Optional[SEType_f64]:
        r"""See Section \ref{sec:blinks}."""
        return cast(Optional[SEType_f64], self.__get(0x00e5))

    @property
    def right_blink_closing_mid_time(self) -> Optional[SEType_u64]:
        r"""See Section \ref{sec:blinks}."""
        return cast(Optional[SEType_u64], self.__get(0x00e6))

    @property
    def right_blink_opening_mid_time(self) -> Optional[SEType_u64]:
        r"""See Section \ref{sec:blinks}."""
        return cast(Optional[SEType_u64], self.__get(0x00e7))

    @property
    def right_blink_closing_amplitude(self) -> Optional[SEType_f64]:
        r"""See Section \ref{sec:blinks}."""
        return cast(Optional[SEType_f64], self.__get(0x00e8))

    @property
    def right_blink_opening_amplitude(self) -> Optional[SEType_f64]:
        r"""See Section \ref{sec:blinks}."""
        return cast(Optional[SEType_f64], self.__get(0x00e9))

    @property
    def right_blink_closing_speed(self) -> Optional[SEType_f64]:
        r"""See Section \ref{sec:blinks}."""
        return cast(Optional[SEType_f64], self.__get(0x00ea))

    @property
    def right_blink_opening_speed(self) -> Optional[SEType_f64]:
        r"""See Section \ref{sec:blinks}."""
        return cast(Optional[SEType_f64], self.__get(0x00eb))

    @property
    def left_eye_outer_corner3d(self) -> Optional[SEType_Point3D]:
        r"""3D position of the left eye outer corner headmodel point."""
        return cast(Optional[SEType_Point3D], self.__get(0x0300))

    @property
    def left_eye_inner_corner3d(self) -> Optional[SEType_Point3D]:
        r"""3D position of the left eye inner corner headmodel point."""
        return cast(Optional[SEType_Point3D], self.__get(0x0301))

    @property
    def right_eye_inner_corner3d(self) -> Optional[SEType_Point3D]:
        r"""3D position of the right eye inner corner headmodel point."""
        return cast(Optional[SEType_Point3D], self.__get(0x0302))

    @property
    def right_eye_outer_corner3d(self) -> Optional[SEType_Point3D]:
        r"""3D position of the right eye outer corner headmodel point."""
        return cast(Optional[SEType_Point3D], self.__get(0x0303))

    @property
    def left_nostril3d(self) -> Optional[SEType_Point3D]:
        r"""3D position of the left nostril headmodel point."""
        return cast(Optional[SEType_Point3D], self.__get(0x0304))

    @property
    def right_nostril3d(self) -> Optional[SEType_Point3D]:
        r"""3D position of the right nostril headmodel point."""
        return cast(Optional[SEType_Point3D], self.__get(0x0305))

    @property
    def left_mouth_corner3d(self) -> Optional[SEType_Point3D]:
        r"""3D position of the left mouth corner headmodel point."""
        return cast(Optional[SEType_Point3D], self.__get(0x0306))

    @property
    def right_mouth_corner3d(self) -> Optional[SEType_Point3D]:
        r"""3D position of the right mouth corner headmodel point."""
        return cast(Optional[SEType_Point3D], self.__get(0x0307))

    @property
    def left_ear3d(self) -> Optional[SEType_Point3D]:
        r"""3D position of the left ear headmodel point."""
        return cast(Optional[SEType_Point3D], self.__get(0x0308))

    @property
    def right_ear3d(self) -> Optional[SEType_Point3D]:
        r"""3D position of the right ear headmodel point."""
        return cast(Optional[SEType_Point3D], self.__get(0x0309))

    @property
    def left_eye_outer_corner2d(self) -> Optional[SEType_Vector[SEType_Vect2D]]:
        r"""2D positions of the left eye outer corner headmodel point projected into all cameras."""
        return cast(Optional[SEType_Vector[SEType_Vect2D]], self.__get(0x0310))

    @property
    def left_eye_inner_corner2d(self) -> Optional[SEType_Vector[SEType_Vect2D]]:
        r"""2D positions of the left eye inner corner headmodel point projected into all cameras."""
        return cast(Optional[SEType_Vector[SEType_Vect2D]], self.__get(0x0311))

    @property
    def right_eye_inner_corner2d(self) -> Optional[SEType_Vector[SEType_Vect2D]]:
        r"""2D positions of the right eye inner corner headmodel point projected into all cameras."""
        return cast(Optional[SEType_Vector[SEType_Vect2D]], self.__get(0x0312))

    @property
    def right_eye_outer_corner2d(self) -> Optional[SEType_Vector[SEType_Vect2D]]:
        r"""2D positions of the right eye outer corner headmodel point projected into all cameras."""
        return cast(Optional[SEType_Vector[SEType_Vect2D]], self.__get(0x0313))

    @property
    def left_nostril2d(self) -> Optional[SEType_Vector[SEType_Vect2D]]:
        r"""2D positions of the left nostril headmodel point projected into all cameras."""
        return cast(Optional[SEType_Vector[SEType_Vect2D]], self.__get(0x0314))

    @property
    def right_nostril2d(self) -> Optional[SEType_Vector[SEType_Vect2D]]:
        r"""2D positions of the right nostril headmodel point projected into all cameras."""
        return cast(Optional[SEType_Vector[SEType_Vect2D]], self.__get(0x0315))

    @property
    def left_mouth_corner2d(self) -> Optional[SEType_Vector[SEType_Vect2D]]:
        r"""2D positions of the left mouth corner headmodel point projected into all cameras."""
        return cast(Optional[SEType_Vector[SEType_Vect2D]], self.__get(0x0316))

    @property
    def right_mouth_corner2d(self) -> Optional[SEType_Vector[SEType_Vect2D]]:
        r"""2D positions of the right mouth corner headmodel point projected into all cameras."""
        return cast(Optional[SEType_Vector[SEType_Vect2D]], self.__get(0x0317))

    @property
    def left_ear2d(self) -> Optional[SEType_Vector[SEType_Vect2D]]:
        r"""2D positions of the left ear headmodel point projected into all cameras."""
        return cast(Optional[SEType_Vector[SEType_Vect2D]], self.__get(0x0318))

    @property
    def right_ear2d(self) -> Optional[SEType_Vector[SEType_Vect2D]]:
        r"""2D positions of the right ear headmodel point projected into all cameras."""
        return cast(Optional[SEType_Vector[SEType_Vect2D]], self.__get(0x0319))

    @property
    def nose_tip2d(self) -> Optional[SEType_Vector[SEType_Vect2D]]:
        r"""2D positions of the nose tip headmodel point projected into all cameras."""
        return cast(Optional[SEType_Vector[SEType_Vect2D]], self.__get(0x0370))

    @property
    def mouth_shape_points2d(self) -> Optional[SEType_Vector[SEType_Point2D]]:
        r"""Vector of mouth shape points in 2D represented by 10 pixel coordinates per camera. The first 10 x,y pairs belong to the first camera, the next 10 to the second, and so on."""
        return cast(Optional[SEType_Vector[SEType_Point2D]], self.__get(0x0320))

    @property
    def left_ear_shape_points2d(self) -> Optional[SEType_Vector[SEType_Point2D]]:
        r"""Vector of left ear shape points in 2D represented by 5 pixel coordinates per camera. The first 5 x,y pairs belong to the first camera, the next 5 to the second, and so on."""
        return cast(Optional[SEType_Vector[SEType_Point2D]], self.__get(0x0321))

    @property
    def right_ear_shape_points2d(self) -> Optional[SEType_Vector[SEType_Point2D]]:
        r"""Vector of right ear shape points in 2D represented by 5 pixel coordinates per camera. The first 5 x,y pairs belong to the first camera, the next 5 to the second, and so on."""
        return cast(Optional[SEType_Vector[SEType_Point2D]], self.__get(0x0322))

    @property
    def nose_shape_points2d(self) -> Optional[SEType_Vector[SEType_Point2D]]:
        r"""Vector of nose shape points in 2D represented by 9 pixel coordinates per camera. The first 9 x,y pairs belong to the first camera, the next 9 to the second, and so on."""
        return cast(Optional[SEType_Vector[SEType_Point2D]], self.__get(0x0323))

    @property
    def left_eye_shape_points2d(self) -> Optional[SEType_Vector[SEType_Point2D]]:
        r"""Vector of left eye shape points in 2D represented by 8 pixel coordinates per camera. The first 8 x,y pairs belong to the first camera, the next 8 to the second, and so on. Output will only be provided for camera-eye pairs where the algorithms selected an eye clip, while it is zeroed for other pairs."""
        return cast(Optional[SEType_Vector[SEType_Point2D]], self.__get(0x0324))

    @property
    def right_eye_shape_points2d(self) -> Optional[SEType_Vector[SEType_Point2D]]:
        r"""Vector of right eye shape points in 2D represented by 8 pixel coordinates per camera. The first 8 x,y pairs belong to the first camera, the next 8 to the second, and so on. Output will only be provided for camera-eye pairs where the algorithms selected an eye clip, while it is zeroed for other pairs."""
        return cast(Optional[SEType_Vector[SEType_Point2D]], self.__get(0x0325))

    @property
    def left_eyelid_state(self) -> Optional[SEType_u8]:
        r"""Detected state of left eyelid. Possible values: "Not Set" (0), "Open" (1), "Closed" (2) or "Unsure" (3)."""
        return cast(Optional[SEType_u8], self.__get(0x0390))

    @property
    def left_eyelid_state_quality(self) -> Optional[SEType_f64]:
        r"""Quality of the left eyelid state."""
        return cast(Optional[SEType_f64], self.__get(0x03f8))

    @property
    def right_eyelid_state(self) -> Optional[SEType_u8]:
        r"""Detected state of right eyelid. Possible values: "Not Set" (0), "Open" (1), "Closed" (2) or "Unsure" (3)."""
        return cast(Optional[SEType_u8], self.__get(0x0391))

    @property
    def right_eyelid_state_quality(self) -> Optional[SEType_f64]:
        r"""Quality of the right eyelid state."""
        return cast(Optional[SEType_f64], self.__get(0x03f9))

    @property
    def user_marker(self) -> Optional[SEType_UserMarker]:
        r"""User defined marker, containing some data and the specific time it was received. The marker could, for example, represent a key press on some external experiment equipment. 
 The marker also contains an "Error" field, containing an error code from the Smart Eye error specification. The start of each subpacket of this type contains a 1 if a marker is received, otherwise 0."""
        return cast(Optional[SEType_UserMarker], self.__get(0x03a0))

    @property
    def camera_clocks(self) -> Optional[SEType_Vector[SEType_u64]]:
        r"""Camera hardware provided time stamps of image exposure. Characteristics of these time stamps are camera dependent."""
        return cast(Optional[SEType_Vector[SEType_u64]], self.__get(0x03a1))

    @property
    def speaking(self) -> Optional[SEType_u8]:
        r"""Binary signal stating if the tracked subject is currently speaking (1) or not speaking (0)."""
        return cast(Optional[SEType_u8], self.__get(0x03f0))

    @property
    def speaking_quality(self) -> Optional[SEType_f64]:
        r"""The current quality of the Speaking signal."""
        return cast(Optional[SEType_f64], self.__get(0x03f1))

    @property
    def profile_id(self) -> Optional[SEType_s32]:
        r"""The unique identifier of the tracked subject."""
        return cast(Optional[SEType_s32], self.__get(0x03f2))

    @property
    def profile_id_quality(self) -> Optional[SEType_f64]:
        r"""The quality of the ProfileId signal."""
        return cast(Optional[SEType_f64], self.__get(0x03f3))

    @property
    def profile_id_state(self) -> Optional[SEType_u8]:
        r"""The current state of the ProfileId algorithm."""
        return cast(Optional[SEType_u8], self.__get(0x03f4))

    @property
    def drowsiness9_level(self) -> Optional[SEType_u8]:
        r"""An estimation of the tracked subject's drowsiness measured on the nine level KSS scale."""
        return cast(Optional[SEType_u8], self.__get(0x03f5))

    @property
    def drowsiness9_level_quality(self) -> Optional[SEType_f64]:
        r"""The current quality of the Drowsiness9Level signal."""
        return cast(Optional[SEType_f64], self.__get(0x03f6))

    @property
    def drowsiness9_level_status(self) -> Optional[SEType_u8]:
        r"""The current status of the Drowsiness9Level module."""
        return cast(Optional[SEType_u8], self.__get(0x03f7))

    @property
    def glasses(self) -> Optional[SEType_u8]:
        r"""Signal stating if the tracked subject is currently wearing translucent glasses (1), opaque glasses (2) or not wearing glasses (0)."""
        return cast(Optional[SEType_u8], self.__get(0x0600))

    @property
    def glasses_quality(self) -> Optional[SEType_f64]:
        r"""The current quality of the Glasses signal."""
        return cast(Optional[SEType_f64], self.__get(0x0601))

    @property
    def face_mask(self) -> Optional[SEType_u8]:
        r"""Binary signal stating if the tracked subject is currently wearing a face mask (1) or not (0)."""
        return cast(Optional[SEType_u8], self.__get(0x0602))

    @property
    def face_mask_quality(self) -> Optional[SEType_f64]:
        r"""The current quality of the FaceMask signal."""
        return cast(Optional[SEType_f64], self.__get(0x0603))

    @property
    def left_eye_occluded(self) -> Optional[SEType_u8]:
        r"""Binary signal stating if the tracked subject's left eye is currently occluded (1) or not (0)."""
        return cast(Optional[SEType_u8], self.__get(0x0604))

    @property
    def left_eye_occluded_quality(self) -> Optional[SEType_f64]:
        r"""The current quality of the LeftEyeOccluded signal."""
        return cast(Optional[SEType_f64], self.__get(0x0605))

    @property
    def right_eye_occluded(self) -> Optional[SEType_u8]:
        r"""Binary signal stating if the tracked subject's right eye is currently occluded (1) or not (0)."""
        return cast(Optional[SEType_u8], self.__get(0x0606))

    @property
    def right_eye_occluded_quality(self) -> Optional[SEType_f64]:
        r"""The current quality of the RightEyeOccluded signal."""
        return cast(Optional[SEType_f64], self.__get(0x0607))

    @property
    def anger(self) -> Optional[SEType_u8]:
        r"""Binary signal stating if the tracked subject is expressing anger (1) or not (0)."""
        return cast(Optional[SEType_u8], self.__get(0x03fa))

    @property
    def anger_quality(self) -> Optional[SEType_f64]:
        r"""Quality of the Anger signal."""
        return cast(Optional[SEType_f64], self.__get(0x03fb))

    @property
    def disgust(self) -> Optional[SEType_u8]:
        r"""Binary signal stating if the tracked subject is expressing disgust (1) or not (0)."""
        return cast(Optional[SEType_u8], self.__get(0x03fc))

    @property
    def disgust_quality(self) -> Optional[SEType_f64]:
        r"""Quality of the Disgust signal."""
        return cast(Optional[SEType_f64], self.__get(0x03fd))

    @property
    def happiness(self) -> Optional[SEType_u8]:
        r"""Binary signal stating if the tracked subject is expressing happiness (1) or not (0)."""
        return cast(Optional[SEType_u8], self.__get(0x03fe))

    @property
    def happiness_quality(self) -> Optional[SEType_f64]:
        r"""Quality of the Happiness signal."""
        return cast(Optional[SEType_f64], self.__get(0x03ff))

    @property
    def neutral(self) -> Optional[SEType_u8]:
        r"""Binary signal stating if the tracked subject's expression is neutral (1) or not (0)."""
        return cast(Optional[SEType_u8], self.__get(0x0503))

    @property
    def neutral_quality(self) -> Optional[SEType_f64]:
        r"""Quality of the Neutral signal."""
        return cast(Optional[SEType_f64], self.__get(0x0504))

    @property
    def sadness(self) -> Optional[SEType_u8]:
        r"""Binary signal stating if the tracked subject is expressing sadness (1) or not (0)."""
        return cast(Optional[SEType_u8], self.__get(0x0505))

    @property
    def sadness_quality(self) -> Optional[SEType_f64]:
        r"""Quality of the Sadness signal."""
        return cast(Optional[SEType_f64], self.__get(0x0506))

    @property
    def surprise(self) -> Optional[SEType_u8]:
        r"""Binary signal stating if the tracked subject is expressing surprise (1) or not (0)."""
        return cast(Optional[SEType_u8], self.__get(0x0507))

    @property
    def surprise_quality(self) -> Optional[SEType_f64]:
        r"""Quality of the Surprise signal."""
        return cast(Optional[SEType_f64], self.__get(0x0508))

    @property
    def valence(self) -> Optional[SEType_f64]:
        r"""Continuous signal stating the emotional state the tracked subject is expressing from unpleasant to pleasant."""
        return cast(Optional[SEType_f64], self.__get(0x0509))

    @property
    def valence_quality(self) -> Optional[SEType_f64]:
        r"""Quality of the Valence signal."""
        return cast(Optional[SEType_f64], self.__get(0x050a))

    @property
    def mood(self) -> Optional[SEType_s32]:
        r"""An enum signal stating the mood of the tracked subject."""
        return cast(Optional[SEType_s32], self.__get(0x050b))

    @property
    def mood_quality(self) -> Optional[SEType_f64]:
        r"""Quality of the Mood signal."""
        return cast(Optional[SEType_f64], self.__get(0x050c))

    @property
    def dominant_emotion(self) -> Optional[SEType_s32]:
        r"""An enum signal stating the dominant emotion of the tracked subject."""
        return cast(Optional[SEType_s32], self.__get(0x050d))

    @property
    def dominant_emotion_quality(self) -> Optional[SEType_f64]:
        r"""Quality of the DominantEmotion signal."""
        return cast(Optional[SEType_f64], self.__get(0x050e))

    def __repr__(self) -> str:
        props = [
            ("frame_number", self.__get(0x0001)),
            ("estimated_delay", self.__get(0x0002)),
            ("time_stamp", self.__get(0x0003)),
            ("user_time_stamp", self.__get(0x0004)),
            ("frame_rate", self.__get(0x0005)),
            ("camera_positions", self.__get(0x0006)),
            ("camera_rotations", self.__get(0x0007)),
            ("user_defined_data", self.__get(0x0008)),
            ("real_time_clock", self.__get(0x0009)),
            ("head_position", self.__get(0x0010)),
            ("head_position_quality", self.__get(0x0011)),
            ("head_rotation_rodrigues", self.__get(0x0012)),
            ("head_rotation_quaternion", self.__get(0x001d)),
            ("head_left_ear_direction", self.__get(0x0015)),
            ("head_up_direction", self.__get(0x0014)),
            ("head_nose_direction", self.__get(0x0013)),
            ("head_heading", self.__get(0x0016)),
            ("head_pitch", self.__get(0x0017)),
            ("head_roll", self.__get(0x0018)),
            ("head_rotation_quality", self.__get(0x0019)),
            ("gaze_origin", self.__get(0x001a)),
            ("left_gaze_origin", self.__get(0x001b)),
            ("right_gaze_origin", self.__get(0x001c)),
            ("eye_position", self.__get(0x0020)),
            ("gaze_direction", self.__get(0x0021)),
            ("gaze_direction_quality", self.__get(0x0022)),
            ("left_eye_position", self.__get(0x0023)),
            ("left_gaze_direction", self.__get(0x0024)),
            ("left_gaze_direction_quality", self.__get(0x0025)),
            ("right_eye_position", self.__get(0x0026)),
            ("right_gaze_direction", self.__get(0x0027)),
            ("right_gaze_direction_quality", self.__get(0x0028)),
            ("gaze_heading", self.__get(0x0029)),
            ("gaze_pitch", self.__get(0x002a)),
            ("left_gaze_heading", self.__get(0x002b)),
            ("left_gaze_pitch", self.__get(0x002c)),
            ("right_gaze_heading", self.__get(0x002d)),
            ("right_gaze_pitch", self.__get(0x002e)),
            ("filtered_gaze_direction", self.__get(0x0030)),
            ("filtered_left_gaze_direction", self.__get(0x0032)),
            ("filtered_right_gaze_direction", self.__get(0x0034)),
            ("filtered_gaze_heading", self.__get(0x0036)),
            ("filtered_gaze_pitch", self.__get(0x0037)),
            ("filtered_left_gaze_heading", self.__get(0x0038)),
            ("filtered_left_gaze_pitch", self.__get(0x0039)),
            ("filtered_right_gaze_heading", self.__get(0x003a)),
            ("filtered_right_gaze_pitch", self.__get(0x003b)),
            ("filtered_gaze_origin", self.__get(0x0500)),
            ("filtered_left_gaze_origin", self.__get(0x0501)),
            ("filtered_right_gaze_origin", self.__get(0x0502)),
            ("saccade", self.__get(0x003d)),
            ("fixation", self.__get(0x003e)),
            ("blink", self.__get(0x003f)),
            ("closest_world_intersection", self.__get(0x0040)),
            ("filtered_closest_world_intersection", self.__get(0x0041)),
            ("all_world_intersections", self.__get(0x0042)),
            ("filtered_all_world_intersections", self.__get(0x0043)),
            ("estimated_closest_world_intersection", self.__get(0x0045)),
            ("estimated_all_world_intersections", self.__get(0x0046)),
            ("head_closest_world_intersection", self.__get(0x0049)),
            ("head_all_world_intersections", self.__get(0x004a)),
            ("eyelid_opening", self.__get(0x0050)),
            ("eyelid_opening_quality", self.__get(0x0051)),
            ("left_eyelid_opening", self.__get(0x0052)),
            ("left_eyelid_opening_quality", self.__get(0x0053)),
            ("right_eyelid_opening", self.__get(0x0054)),
            ("right_eyelid_opening_quality", self.__get(0x0055)),
            ("keyboard_state", self.__get(0x0056)),
            ("pupil_diameter", self.__get(0x0060)),
            ("pupil_diameter_quality", self.__get(0x0061)),
            ("left_pupil_diameter", self.__get(0x0062)),
            ("left_pupil_diameter_quality", self.__get(0x0063)),
            ("right_pupil_diameter", self.__get(0x0064)),
            ("right_pupil_diameter_quality", self.__get(0x0065)),
            ("filtered_pupil_diameter", self.__get(0x0066)),
            ("filtered_pupil_diameter_quality", self.__get(0x0067)),
            ("filtered_left_pupil_diameter", self.__get(0x0068)),
            ("filtered_left_pupil_diameter_quality", self.__get(0x0069)),
            ("filtered_right_pupil_diameter", self.__get(0x006a)),
            ("filtered_right_pupil_diameter_quality", self.__get(0x006b)),
            ("gps_position", self.__get(0x0070)),
            ("gps_ground_speed", self.__get(0x0071)),
            ("gps_course", self.__get(0x0072)),
            ("gps_time", self.__get(0x0073)),
            ("estimated_gaze_origin", self.__get(0x007a)),
            ("estimated_left_gaze_origin", self.__get(0x007b)),
            ("estimated_right_gaze_origin", self.__get(0x007c)),
            ("estimated_eye_position", self.__get(0x0080)),
            ("estimated_gaze_direction", self.__get(0x0081)),
            ("estimated_gaze_direction_quality", self.__get(0x0082)),
            ("estimated_gaze_heading", self.__get(0x0083)),
            ("estimated_gaze_pitch", self.__get(0x0084)),
            ("estimated_left_eye_position", self.__get(0x0085)),
            ("estimated_left_gaze_direction", self.__get(0x0086)),
            ("estimated_left_gaze_direction_quality", self.__get(0x0087)),
            ("estimated_left_gaze_heading", self.__get(0x0088)),
            ("estimated_left_gaze_pitch", self.__get(0x0089)),
            ("estimated_right_eye_position", self.__get(0x008a)),
            ("estimated_right_gaze_direction", self.__get(0x008b)),
            ("estimated_right_gaze_direction_quality", self.__get(0x008c)),
            ("estimated_right_gaze_heading", self.__get(0x008d)),
            ("estimated_right_gaze_pitch", self.__get(0x008e)),
            ("filtered_estimated_gaze_direction", self.__get(0x0091)),
            ("filtered_estimated_gaze_direction_quality", self.__get(0x0092)),
            ("filtered_estimated_gaze_heading", self.__get(0x0093)),
            ("filtered_estimated_gaze_pitch", self.__get(0x0094)),
            ("filtered_estimated_left_gaze_direction", self.__get(0x0096)),
            ("filtered_estimated_left_gaze_direction_quality", self.__get(0x0097)),
            ("filtered_estimated_left_gaze_heading", self.__get(0x0098)),
            ("filtered_estimated_left_gaze_pitch", self.__get(0x0099)),
            ("filtered_estimated_right_gaze_direction", self.__get(0x009b)),
            ("filtered_estimated_right_gaze_direction_quality", self.__get(0x009c)),
            ("filtered_estimated_right_gaze_heading", self.__get(0x009d)),
            ("filtered_estimated_right_gaze_pitch", self.__get(0x009e)),
            ("ascii_keyboard_state", self.__get(0x00a4)),
            ("calibration_gaze_intersection", self.__get(0x00b0)),
            ("tagged_gaze_intersection", self.__get(0x00b1)),
            ("left_closest_world_intersection", self.__get(0x00b2)),
            ("left_all_world_intersections", self.__get(0x00b3)),
            ("right_closest_world_intersection", self.__get(0x00b4)),
            ("right_all_world_intersections", self.__get(0x00b5)),
            ("filtered_left_closest_world_intersection", self.__get(0x00b6)),
            ("filtered_left_all_world_intersections", self.__get(0x00b7)),
            ("filtered_right_closest_world_intersection", self.__get(0x00b8)),
            ("filtered_right_all_world_intersections", self.__get(0x00b9)),
            ("estimated_left_closest_world_intersection", self.__get(0x00ba)),
            ("estimated_left_all_world_intersections", self.__get(0x00bb)),
            ("estimated_right_closest_world_intersection", self.__get(0x00bc)),
            ("estimated_right_all_world_intersections", self.__get(0x00bd)),
            ("filtered_estimated_closest_world_intersection", self.__get(0x0141)),
            ("filtered_estimated_all_world_intersections", self.__get(0x0143)),
            ("filtered_estimated_left_closest_world_intersection", self.__get(0x01b6)),
            ("filtered_estimated_left_all_world_intersections", self.__get(0x01b7)),
            ("filtered_estimated_right_closest_world_intersection", self.__get(0x01b8)),
            ("filtered_estimated_right_all_world_intersections", self.__get(0x01b9)),
            ("all_world_cone_intersections", self.__get(0x01ba)),
            ("left_all_world_cone_intersections", self.__get(0x01bb)),
            ("right_all_world_cone_intersections", self.__get(0x01bc)),
            ("filtered_all_world_cone_intersections", self.__get(0x01bd)),
            ("filtered_left_all_world_cone_intersections", self.__get(0x01be)),
            ("filtered_right_all_world_cone_intersections", self.__get(0x01bf)),
            ("left_blink_closing_mid_time", self.__get(0x00e0)),
            ("left_blink_opening_mid_time", self.__get(0x00e1)),
            ("left_blink_closing_amplitude", self.__get(0x00e2)),
            ("left_blink_opening_amplitude", self.__get(0x00e3)),
            ("left_blink_closing_speed", self.__get(0x00e4)),
            ("left_blink_opening_speed", self.__get(0x00e5)),
            ("right_blink_closing_mid_time", self.__get(0x00e6)),
            ("right_blink_opening_mid_time", self.__get(0x00e7)),
            ("right_blink_closing_amplitude", self.__get(0x00e8)),
            ("right_blink_opening_amplitude", self.__get(0x00e9)),
            ("right_blink_closing_speed", self.__get(0x00ea)),
            ("right_blink_opening_speed", self.__get(0x00eb)),
            ("left_eye_outer_corner3d", self.__get(0x0300)),
            ("left_eye_inner_corner3d", self.__get(0x0301)),
            ("right_eye_inner_corner3d", self.__get(0x0302)),
            ("right_eye_outer_corner3d", self.__get(0x0303)),
            ("left_nostril3d", self.__get(0x0304)),
            ("right_nostril3d", self.__get(0x0305)),
            ("left_mouth_corner3d", self.__get(0x0306)),
            ("right_mouth_corner3d", self.__get(0x0307)),
            ("left_ear3d", self.__get(0x0308)),
            ("right_ear3d", self.__get(0x0309)),
            ("left_eye_outer_corner2d", self.__get(0x0310)),
            ("left_eye_inner_corner2d", self.__get(0x0311)),
            ("right_eye_inner_corner2d", self.__get(0x0312)),
            ("right_eye_outer_corner2d", self.__get(0x0313)),
            ("left_nostril2d", self.__get(0x0314)),
            ("right_nostril2d", self.__get(0x0315)),
            ("left_mouth_corner2d", self.__get(0x0316)),
            ("right_mouth_corner2d", self.__get(0x0317)),
            ("left_ear2d", self.__get(0x0318)),
            ("right_ear2d", self.__get(0x0319)),
            ("nose_tip2d", self.__get(0x0370)),
            ("mouth_shape_points2d", self.__get(0x0320)),
            ("left_ear_shape_points2d", self.__get(0x0321)),
            ("right_ear_shape_points2d", self.__get(0x0322)),
            ("nose_shape_points2d", self.__get(0x0323)),
            ("left_eye_shape_points2d", self.__get(0x0324)),
            ("right_eye_shape_points2d", self.__get(0x0325)),
            ("left_eyelid_state", self.__get(0x0390)),
            ("left_eyelid_state_quality", self.__get(0x03f8)),
            ("right_eyelid_state", self.__get(0x0391)),
            ("right_eyelid_state_quality", self.__get(0x03f9)),
            ("user_marker", self.__get(0x03a0)),
            ("camera_clocks", self.__get(0x03a1)),
            ("speaking", self.__get(0x03f0)),
            ("speaking_quality", self.__get(0x03f1)),
            ("profile_id", self.__get(0x03f2)),
            ("profile_id_quality", self.__get(0x03f3)),
            ("profile_id_state", self.__get(0x03f4)),
            ("drowsiness9_level", self.__get(0x03f5)),
            ("drowsiness9_level_quality", self.__get(0x03f6)),
            ("drowsiness9_level_status", self.__get(0x03f7)),
            ("glasses", self.__get(0x0600)),
            ("glasses_quality", self.__get(0x0601)),
            ("face_mask", self.__get(0x0602)),
            ("face_mask_quality", self.__get(0x0603)),
            ("left_eye_occluded", self.__get(0x0604)),
            ("left_eye_occluded_quality", self.__get(0x0605)),
            ("right_eye_occluded", self.__get(0x0606)),
            ("right_eye_occluded_quality", self.__get(0x0607)),
            ("anger", self.__get(0x03fa)),
            ("anger_quality", self.__get(0x03fb)),
            ("disgust", self.__get(0x03fc)),
            ("disgust_quality", self.__get(0x03fd)),
            ("happiness", self.__get(0x03fe)),
            ("happiness_quality", self.__get(0x03ff)),
            ("neutral", self.__get(0x0503)),
            ("neutral_quality", self.__get(0x0504)),
            ("sadness", self.__get(0x0505)),
            ("sadness_quality", self.__get(0x0506)),
            ("surprise", self.__get(0x0507)),
            ("surprise_quality", self.__get(0x0508)),
            ("valence", self.__get(0x0509)),
            ("valence_quality", self.__get(0x050a)),
            ("mood", self.__get(0x050b)),
            ("mood_quality", self.__get(0x050c)),
            ("dominant_emotion", self.__get(0x050d)),
            ("dominant_emotion_quality", self.__get(0x050e)),
        ]
        props_str = ", ".join([f"{p}={val}" for p, val in props if val is not None])
        return f"Packet({props_str})"
