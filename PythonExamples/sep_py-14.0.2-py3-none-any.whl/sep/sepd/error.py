class ParseError(Exception):
    """Base exception for parsing errors."""

    pass


class NotEnoughDataError(ParseError):
    """
    Raised when trying to parse a type larger than provided data.
    """

    def __init__(self) -> None:
        super().__init__("Not enough data")


class UnknownTypeError(ParseError):
    """Raised when an unknown data type is encountered."""

    def __init__(self, type_id: int) -> None:
        super().__init__(f"Unknown data type: '0x{type_id:04x}'")
        self.type_id: int = type_id


class UnknownOutputDataError(ParseError):
    """Raised when an unknown data output is encountered."""

    def __init__(self, data_output_id: int) -> None:
        super().__init__(f"Unknown output data: '0x{data_output_id:04x}'")
        self.data_output_id: int = data_output_id
