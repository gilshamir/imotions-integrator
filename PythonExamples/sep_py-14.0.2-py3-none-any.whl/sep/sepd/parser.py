import logging
from enum import Enum
from typing import Generator, Sequence

from ..se_types import SEType_Any, SEType_u16
from .error import NotEnoughDataError, ParseError
from .format import parse_packet_header, parse_subpacket, skip_subpacket
from .packet import Packet

LOGGER = logging.getLogger(__name__)


class _ParserState(Enum):
    START = 0
    FIND_PACKET_HEADER = 1
    BUFFER_PACKET = 2
    PARSE_PACKET = 3


class Parser:
    """Parser for streams or discrete packets of sepd encoded bytes."""

    def __init__(self) -> None:
        self._state = _ParserState.START
        self._buffer = b""
        self._packet_length = 0

    def _flush_stream(self) -> bool:
        had_state = self._state != _ParserState.START
        self._state = _ParserState.START
        self._buffer = b""
        return had_state

    def _start(self) -> _ParserState:
        if self._buffer:
            return _ParserState.FIND_PACKET_HEADER
        else:
            return _ParserState.START

    def _find_packet_header(self) -> _ParserState:
        try:
            self._buffer, packet_header = parse_packet_header(self._buffer)
        except NotEnoughDataError:
            return _ParserState.FIND_PACKET_HEADER

        if packet_header.sync_id != 0x53455044:
            raise ParseError(f"SEPacketHeader: Bad syncID ('{packet_header.sync_id}')")
        if packet_header.packet_type != 4:
            raise ParseError(
                f"SEPacketHeader: Bad packetType ('{packet_header.packet_type}')"
            )

        self._packet_length = packet_header.length
        return _ParserState.BUFFER_PACKET

    def _buffer_packet(self) -> _ParserState:
        if len(self._buffer) >= self._packet_length:
            return _ParserState.PARSE_PACKET
        else:
            return _ParserState.BUFFER_PACKET

    def _parse_packet(self) -> tuple[_ParserState, Packet]:
        packet_buffer = self._buffer[: self._packet_length]
        self._buffer = self._buffer[self._packet_length :]
        data: dict[SEType_u16, SEType_Any] = {}
        while packet_buffer:
            try:
                packet_buffer, sub_packet = parse_subpacket(packet_buffer)
                data[sub_packet.header.id] = sub_packet.data
            except ParseError as e:
                LOGGER.warning(f"Failed parsing subpacket: {e}")
                packet_buffer = skip_subpacket(packet_buffer)
        return (_ParserState.START, Packet(data))

    def _parse_stream(self, stream: bytes) -> Generator[Packet, None, None]:
        self._buffer += stream
        while True:
            next_state: _ParserState = self._state
            if self._state == _ParserState.START:
                next_state = self._start()
            elif self._state == _ParserState.FIND_PACKET_HEADER:
                next_state = self._find_packet_header()
            elif self._state == _ParserState.BUFFER_PACKET:
                next_state = self._buffer_packet()
            elif self._state == _ParserState.PARSE_PACKET:
                next_state, packet = self._parse_packet()
                yield packet
            else:
                raise RuntimeError(f"Parser: Invalid state {self._state}")
            # We always expect transition, unless more stream data required.
            if next_state == self._state:
                break
            self._state = next_state

    def flush_stream(self) -> bool:
        """Flushes the parser, resetting state maintained between calls to
        parse_stream. Use this method to signal that the stream was
        interrupted before calling parse_stream again.

        Returns `True` if the Parser had any state before this call.
        """
        return self._flush_stream()

    def parse_stream(self, stream: bytes) -> Sequence[Packet]:
        """Parses stream as 0..n Packets. Use this method for parsing a
        stream of Packet bytes, like received through TCP.

        Raises ParseError if stream is invalid.
        """
        return list(self._parse_stream(stream))

    def parse_packet(self, raw_packet: bytes) -> Packet:
        """Parses raw_packet as a Packet. Use for discrete packets, like
        received through UDP.

        Raises ParseError if raw_packet is invalid, or if it can not be parsed
        as exactly one Packet.
        """
        self.flush_stream()
        # Parse packet as a stream, but expect to parse _exactly_ one Packet.
        ps = self.parse_stream(raw_packet)
        if not ps:
            raise ParseError("raw_packet was not a complete packet")
        if self.flush_stream() or len(ps) > 1:
            raise ParseError("raw_packet was more than exactly one packet")
        return ps[0]
