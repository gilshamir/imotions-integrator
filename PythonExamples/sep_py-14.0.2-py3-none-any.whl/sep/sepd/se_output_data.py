# Note: This file is generated from 'se_output_data.py.jinja2'!
import enum
from typing import Optional

from ..se_type_id import SETypeId

@enum.unique
class SEOutputDataId(enum.Enum):
    SEFrameNumber = 1
    SEEstimatedDelay = 2
    SETimeStamp = 3
    SEUserTimeStamp = 4
    SEFrameRate = 5
    SECameraPositions = 6
    SECameraRotations = 7
    SEUserDefinedData = 8
    SERealTimeClock = 9
    SEHeadPosition = 16
    SEHeadPositionQ = 17
    SEHeadRotationRodrigues = 18
    SEHeadRotationQuaternion = 29
    SEHeadLeftEarDirection = 21
    SEHeadUpDirection = 20
    SEHeadNoseDirection = 19
    SEHeadHeading = 22
    SEHeadPitch = 23
    SEHeadRoll = 24
    SEHeadRotationQ = 25
    SEGazeOrigin = 26
    SELeftGazeOrigin = 27
    SERightGazeOrigin = 28
    SEEyePosition = 32
    SEGazeDirection = 33
    SEGazeDirectionQ = 34
    SELeftEyePosition = 35
    SELeftGazeDirection = 36
    SELeftGazeDirectionQ = 37
    SERightEyePosition = 38
    SERightGazeDirection = 39
    SERightGazeDirectionQ = 40
    SEGazeHeading = 41
    SEGazePitch = 42
    SELeftGazeHeading = 43
    SELeftGazePitch = 44
    SERightGazeHeading = 45
    SERightGazePitch = 46
    SEFilteredGazeDirection = 48
    SEFilteredLeftGazeDirection = 50
    SEFilteredRightGazeDirection = 52
    SEFilteredGazeHeading = 54
    SEFilteredGazePitch = 55
    SEFilteredLeftGazeHeading = 56
    SEFilteredLeftGazePitch = 57
    SEFilteredRightGazeHeading = 58
    SEFilteredRightGazePitch = 59
    SEFilteredGazeOrigin = 1280
    SEFilteredLeftGazeOrigin = 1281
    SEFilteredRightGazeOrigin = 1282
    SESaccade = 61
    SEFixation = 62
    SEBlink = 63
    SEClosestWorldIntersection = 64
    SEFilteredClosestWorldIntersection = 65
    SEAllWorldIntersections = 66
    SEFilteredAllWorldIntersections = 67
    SEEstimatedClosestWorldIntersection = 69
    SEEstimatedAllWorldIntersections = 70
    SEHeadClosestWorldIntersection = 73
    SEHeadAllWorldIntersections = 74
    SEEyelidOpening = 80
    SEEyelidOpeningQ = 81
    SELeftEyelidOpening = 82
    SELeftEyelidOpeningQ = 83
    SERightEyelidOpening = 84
    SERightEyelidOpeningQ = 85
    SEKeyboardState = 86
    SEPupilDiameter = 96
    SEPupilDiameterQ = 97
    SELeftPupilDiameter = 98
    SELeftPupilDiameterQ = 99
    SERightPupilDiameter = 100
    SERightPupilDiameterQ = 101
    SEFilteredPupilDiameter = 102
    SEFilteredPupilDiameterQ = 103
    SEFilteredLeftPupilDiameter = 104
    SEFilteredLeftPupilDiameterQ = 105
    SEFilteredRightPupilDiameter = 106
    SEFilteredRightPupilDiameterQ = 107
    SEGPSPosition = 112
    SEGPSGroundSpeed = 113
    SEGPSCourse = 114
    SEGPSTime = 115
    SEEstimatedGazeOrigin = 122
    SEEstimatedLeftGazeOrigin = 123
    SEEstimatedRightGazeOrigin = 124
    SEEstimatedEyePosition = 128
    SEEstimatedGazeDirection = 129
    SEEstimatedGazeDirectionQ = 130
    SEEstimatedGazeHeading = 131
    SEEstimatedGazePitch = 132
    SEEstimatedLeftEyePosition = 133
    SEEstimatedLeftGazeDirection = 134
    SEEstimatedLeftGazeDirectionQ = 135
    SEEstimatedLeftGazeHeading = 136
    SEEstimatedLeftGazePitch = 137
    SEEstimatedRightEyePosition = 138
    SEEstimatedRightGazeDirection = 139
    SEEstimatedRightGazeDirectionQ = 140
    SEEstimatedRightGazeHeading = 141
    SEEstimatedRightGazePitch = 142
    SEFilteredEstimatedGazeDirection = 145
    SEFilteredEstimatedGazeDirectionQ = 146
    SEFilteredEstimatedGazeHeading = 147
    SEFilteredEstimatedGazePitch = 148
    SEFilteredEstimatedLeftGazeDirection = 150
    SEFilteredEstimatedLeftGazeDirectionQ = 151
    SEFilteredEstimatedLeftGazeHeading = 152
    SEFilteredEstimatedLeftGazePitch = 153
    SEFilteredEstimatedRightGazeDirection = 155
    SEFilteredEstimatedRightGazeDirectionQ = 156
    SEFilteredEstimatedRightGazeHeading = 157
    SEFilteredEstimatedRightGazePitch = 158
    SEASCIIKeyboardState = 164
    SECalibrationGazeIntersection = 176
    SETaggedGazeIntersection = 177
    SELeftClosestWorldIntersection = 178
    SELeftAllWorldIntersections = 179
    SERightClosestWorldIntersection = 180
    SERightAllWorldIntersections = 181
    SEFilteredLeftClosestWorldIntersection = 182
    SEFilteredLeftAllWorldIntersections = 183
    SEFilteredRightClosestWorldIntersection = 184
    SEFilteredRightAllWorldIntersections = 185
    SEEstimatedLeftClosestWorldIntersection = 186
    SEEstimatedLeftAllWorldIntersections = 187
    SEEstimatedRightClosestWorldIntersection = 188
    SEEstimatedRightAllWorldIntersections = 189
    SEFilteredEstimatedClosestWorldIntersection = 321
    SEFilteredEstimatedAllWorldIntersections = 323
    SEFilteredEstimatedLeftClosestWorldIntersection = 438
    SEFilteredEstimatedLeftAllWorldIntersections = 439
    SEFilteredEstimatedRightClosestWorldIntersection = 440
    SEFilteredEstimatedRightAllWorldIntersections = 441
    SEAllWorldConeIntersections = 442
    SELeftAllWorldConeIntersections = 443
    SERightAllWorldConeIntersections = 444
    SEFilteredAllWorldConeIntersections = 445
    SEFilteredLeftAllWorldConeIntersections = 446
    SEFilteredRightAllWorldConeIntersections = 447
    SELeftBlinkClosingMidTime = 224
    SELeftBlinkOpeningMidTime = 225
    SELeftBlinkClosingAmplitude = 226
    SELeftBlinkOpeningAmplitude = 227
    SELeftBlinkClosingSpeed = 228
    SELeftBlinkOpeningSpeed = 229
    SERightBlinkClosingMidTime = 230
    SERightBlinkOpeningMidTime = 231
    SERightBlinkClosingAmplitude = 232
    SERightBlinkOpeningAmplitude = 233
    SERightBlinkClosingSpeed = 234
    SERightBlinkOpeningSpeed = 235
    SELeftEyeOuterCorner3D = 768
    SELeftEyeInnerCorner3D = 769
    SERightEyeInnerCorner3D = 770
    SERightEyeOuterCorner3D = 771
    SELeftNostril3D = 772
    SERightNostril3D = 773
    SELeftMouthCorner3D = 774
    SERightMouthCorner3D = 775
    SELeftEar3D = 776
    SERightEar3D = 777
    SELeftEyeOuterCorner2D = 784
    SELeftEyeInnerCorner2D = 785
    SERightEyeInnerCorner2D = 786
    SERightEyeOuterCorner2D = 787
    SELeftNostril2D = 788
    SERightNostril2D = 789
    SELeftMouthCorner2D = 790
    SERightMouthCorner2D = 791
    SELeftEar2D = 792
    SERightEar2D = 793
    SENoseTip2D = 880
    SEMouthShapePoints2D = 800
    SELeftEarShapePoints2D = 801
    SERightEarShapePoints2D = 802
    SENoseShapePoints2D = 803
    SELeftEyeShapePoints2D = 804
    SERightEyeShapePoints2D = 805
    SELeftEyelidState = 912
    SELeftEyelidStateQ = 1016
    SERightEyelidState = 913
    SERightEyelidStateQ = 1017
    SEUserMarker = 928
    SECameraClocks = 929
    SESpeaking = 1008
    SESpeakingQ = 1009
    SEProfileId = 1010
    SEProfileIdQ = 1011
    SEProfileIdState = 1012
    SEDrowsiness9Level = 1013
    SEDrowsiness9LevelQ = 1014
    SEDrowsiness9LevelStatus = 1015
    SEGlasses = 1536
    SEGlassesQ = 1537
    SEFaceMask = 1538
    SEFaceMaskQ = 1539
    SELeftEyeOccluded = 1540
    SELeftEyeOccludedQ = 1541
    SERightEyeOccluded = 1542
    SERightEyeOccludedQ = 1543
    SEAnger = 1018
    SEAngerQ = 1019
    SEDisgust = 1020
    SEDisgustQ = 1021
    SEHappiness = 1022
    SEHappinessQ = 1023
    SENeutral = 1283
    SENeutralQ = 1284
    SESadness = 1285
    SESadnessQ = 1286
    SESurprise = 1287
    SESurpriseQ = 1288
    SEValence = 1289
    SEValenceQ = 1290
    SEMood = 1291
    SEMoodQ = 1292
    SEDominantEmotion = 1293
    SEDominantEmotionQ = 1294


_OUTPUT_DATA_ID_TO_TYPE_ID: dict[SEOutputDataId, SETypeId] = {
    SEOutputDataId.SEFrameNumber: SETypeId.SEType_u32,
    SEOutputDataId.SEEstimatedDelay: SETypeId.SEType_u32,
    SEOutputDataId.SETimeStamp: SETypeId.SEType_u64,
    SEOutputDataId.SEUserTimeStamp: SETypeId.SEType_u64,
    SEOutputDataId.SEFrameRate: SETypeId.SEType_f64,
    SEOutputDataId.SECameraPositions: SETypeId.SEType_Vector,
    SEOutputDataId.SECameraRotations: SETypeId.SEType_Vector,
    SEOutputDataId.SEUserDefinedData: SETypeId.SEType_u64,
    SEOutputDataId.SERealTimeClock: SETypeId.SEType_u64,
    SEOutputDataId.SEHeadPosition: SETypeId.SEType_Point3D,
    SEOutputDataId.SEHeadPositionQ: SETypeId.SEType_f64,
    SEOutputDataId.SEHeadRotationRodrigues: SETypeId.SEType_Vect3D,
    SEOutputDataId.SEHeadRotationQuaternion: SETypeId.SEType_Quaternion,
    SEOutputDataId.SEHeadLeftEarDirection: SETypeId.SEType_Vect3D,
    SEOutputDataId.SEHeadUpDirection: SETypeId.SEType_Vect3D,
    SEOutputDataId.SEHeadNoseDirection: SETypeId.SEType_Vect3D,
    SEOutputDataId.SEHeadHeading: SETypeId.SEType_f64,
    SEOutputDataId.SEHeadPitch: SETypeId.SEType_f64,
    SEOutputDataId.SEHeadRoll: SETypeId.SEType_f64,
    SEOutputDataId.SEHeadRotationQ: SETypeId.SEType_f64,
    SEOutputDataId.SEGazeOrigin: SETypeId.SEType_Point3D,
    SEOutputDataId.SELeftGazeOrigin: SETypeId.SEType_Point3D,
    SEOutputDataId.SERightGazeOrigin: SETypeId.SEType_Point3D,
    SEOutputDataId.SEEyePosition: SETypeId.SEType_Point3D,
    SEOutputDataId.SEGazeDirection: SETypeId.SEType_Vect3D,
    SEOutputDataId.SEGazeDirectionQ: SETypeId.SEType_f64,
    SEOutputDataId.SELeftEyePosition: SETypeId.SEType_Point3D,
    SEOutputDataId.SELeftGazeDirection: SETypeId.SEType_Vect3D,
    SEOutputDataId.SELeftGazeDirectionQ: SETypeId.SEType_f64,
    SEOutputDataId.SERightEyePosition: SETypeId.SEType_Point3D,
    SEOutputDataId.SERightGazeDirection: SETypeId.SEType_Vect3D,
    SEOutputDataId.SERightGazeDirectionQ: SETypeId.SEType_f64,
    SEOutputDataId.SEGazeHeading: SETypeId.SEType_f64,
    SEOutputDataId.SEGazePitch: SETypeId.SEType_f64,
    SEOutputDataId.SELeftGazeHeading: SETypeId.SEType_f64,
    SEOutputDataId.SELeftGazePitch: SETypeId.SEType_f64,
    SEOutputDataId.SERightGazeHeading: SETypeId.SEType_f64,
    SEOutputDataId.SERightGazePitch: SETypeId.SEType_f64,
    SEOutputDataId.SEFilteredGazeDirection: SETypeId.SEType_Vect3D,
    SEOutputDataId.SEFilteredLeftGazeDirection: SETypeId.SEType_Vect3D,
    SEOutputDataId.SEFilteredRightGazeDirection: SETypeId.SEType_Vect3D,
    SEOutputDataId.SEFilteredGazeHeading: SETypeId.SEType_f64,
    SEOutputDataId.SEFilteredGazePitch: SETypeId.SEType_f64,
    SEOutputDataId.SEFilteredLeftGazeHeading: SETypeId.SEType_f64,
    SEOutputDataId.SEFilteredLeftGazePitch: SETypeId.SEType_f64,
    SEOutputDataId.SEFilteredRightGazeHeading: SETypeId.SEType_f64,
    SEOutputDataId.SEFilteredRightGazePitch: SETypeId.SEType_f64,
    SEOutputDataId.SEFilteredGazeOrigin: SETypeId.SEType_Point3D,
    SEOutputDataId.SEFilteredLeftGazeOrigin: SETypeId.SEType_Point3D,
    SEOutputDataId.SEFilteredRightGazeOrigin: SETypeId.SEType_Point3D,
    SEOutputDataId.SESaccade: SETypeId.SEType_u32,
    SEOutputDataId.SEFixation: SETypeId.SEType_u32,
    SEOutputDataId.SEBlink: SETypeId.SEType_u32,
    SEOutputDataId.SEClosestWorldIntersection: SETypeId.SEType_WorldIntersection,
    SEOutputDataId.SEFilteredClosestWorldIntersection: SETypeId.SEType_WorldIntersection,
    SEOutputDataId.SEAllWorldIntersections: SETypeId.SEType_WorldIntersections,
    SEOutputDataId.SEFilteredAllWorldIntersections: SETypeId.SEType_WorldIntersections,
    SEOutputDataId.SEEstimatedClosestWorldIntersection: SETypeId.SEType_WorldIntersection,
    SEOutputDataId.SEEstimatedAllWorldIntersections: SETypeId.SEType_WorldIntersections,
    SEOutputDataId.SEHeadClosestWorldIntersection: SETypeId.SEType_WorldIntersection,
    SEOutputDataId.SEHeadAllWorldIntersections: SETypeId.SEType_WorldIntersections,
    SEOutputDataId.SEEyelidOpening: SETypeId.SEType_f64,
    SEOutputDataId.SEEyelidOpeningQ: SETypeId.SEType_f64,
    SEOutputDataId.SELeftEyelidOpening: SETypeId.SEType_f64,
    SEOutputDataId.SELeftEyelidOpeningQ: SETypeId.SEType_f64,
    SEOutputDataId.SERightEyelidOpening: SETypeId.SEType_f64,
    SEOutputDataId.SERightEyelidOpeningQ: SETypeId.SEType_f64,
    SEOutputDataId.SEKeyboardState: SETypeId.SEType_String,
    SEOutputDataId.SEPupilDiameter: SETypeId.SEType_f64,
    SEOutputDataId.SEPupilDiameterQ: SETypeId.SEType_f64,
    SEOutputDataId.SELeftPupilDiameter: SETypeId.SEType_f64,
    SEOutputDataId.SELeftPupilDiameterQ: SETypeId.SEType_f64,
    SEOutputDataId.SERightPupilDiameter: SETypeId.SEType_f64,
    SEOutputDataId.SERightPupilDiameterQ: SETypeId.SEType_f64,
    SEOutputDataId.SEFilteredPupilDiameter: SETypeId.SEType_f64,
    SEOutputDataId.SEFilteredPupilDiameterQ: SETypeId.SEType_f64,
    SEOutputDataId.SEFilteredLeftPupilDiameter: SETypeId.SEType_f64,
    SEOutputDataId.SEFilteredLeftPupilDiameterQ: SETypeId.SEType_f64,
    SEOutputDataId.SEFilteredRightPupilDiameter: SETypeId.SEType_f64,
    SEOutputDataId.SEFilteredRightPupilDiameterQ: SETypeId.SEType_f64,
    SEOutputDataId.SEGPSPosition: SETypeId.SEType_Point2D,
    SEOutputDataId.SEGPSGroundSpeed: SETypeId.SEType_f64,
    SEOutputDataId.SEGPSCourse: SETypeId.SEType_f64,
    SEOutputDataId.SEGPSTime: SETypeId.SEType_u64,
    SEOutputDataId.SEEstimatedGazeOrigin: SETypeId.SEType_Point3D,
    SEOutputDataId.SEEstimatedLeftGazeOrigin: SETypeId.SEType_Point3D,
    SEOutputDataId.SEEstimatedRightGazeOrigin: SETypeId.SEType_Point3D,
    SEOutputDataId.SEEstimatedEyePosition: SETypeId.SEType_Point3D,
    SEOutputDataId.SEEstimatedGazeDirection: SETypeId.SEType_Vect3D,
    SEOutputDataId.SEEstimatedGazeDirectionQ: SETypeId.SEType_f64,
    SEOutputDataId.SEEstimatedGazeHeading: SETypeId.SEType_f64,
    SEOutputDataId.SEEstimatedGazePitch: SETypeId.SEType_f64,
    SEOutputDataId.SEEstimatedLeftEyePosition: SETypeId.SEType_Point3D,
    SEOutputDataId.SEEstimatedLeftGazeDirection: SETypeId.SEType_Vect3D,
    SEOutputDataId.SEEstimatedLeftGazeDirectionQ: SETypeId.SEType_f64,
    SEOutputDataId.SEEstimatedLeftGazeHeading: SETypeId.SEType_f64,
    SEOutputDataId.SEEstimatedLeftGazePitch: SETypeId.SEType_f64,
    SEOutputDataId.SEEstimatedRightEyePosition: SETypeId.SEType_Point3D,
    SEOutputDataId.SEEstimatedRightGazeDirection: SETypeId.SEType_Vect3D,
    SEOutputDataId.SEEstimatedRightGazeDirectionQ: SETypeId.SEType_f64,
    SEOutputDataId.SEEstimatedRightGazeHeading: SETypeId.SEType_f64,
    SEOutputDataId.SEEstimatedRightGazePitch: SETypeId.SEType_f64,
    SEOutputDataId.SEFilteredEstimatedGazeDirection: SETypeId.SEType_Vect3D,
    SEOutputDataId.SEFilteredEstimatedGazeDirectionQ: SETypeId.SEType_f64,
    SEOutputDataId.SEFilteredEstimatedGazeHeading: SETypeId.SEType_f64,
    SEOutputDataId.SEFilteredEstimatedGazePitch: SETypeId.SEType_f64,
    SEOutputDataId.SEFilteredEstimatedLeftGazeDirection: SETypeId.SEType_Vect3D,
    SEOutputDataId.SEFilteredEstimatedLeftGazeDirectionQ: SETypeId.SEType_f64,
    SEOutputDataId.SEFilteredEstimatedLeftGazeHeading: SETypeId.SEType_f64,
    SEOutputDataId.SEFilteredEstimatedLeftGazePitch: SETypeId.SEType_f64,
    SEOutputDataId.SEFilteredEstimatedRightGazeDirection: SETypeId.SEType_Vect3D,
    SEOutputDataId.SEFilteredEstimatedRightGazeDirectionQ: SETypeId.SEType_f64,
    SEOutputDataId.SEFilteredEstimatedRightGazeHeading: SETypeId.SEType_f64,
    SEOutputDataId.SEFilteredEstimatedRightGazePitch: SETypeId.SEType_f64,
    SEOutputDataId.SEASCIIKeyboardState: SETypeId.SEType_u16,
    SEOutputDataId.SECalibrationGazeIntersection: SETypeId.SEType_WorldIntersection,
    SEOutputDataId.SETaggedGazeIntersection: SETypeId.SEType_WorldIntersection,
    SEOutputDataId.SELeftClosestWorldIntersection: SETypeId.SEType_WorldIntersection,
    SEOutputDataId.SELeftAllWorldIntersections: SETypeId.SEType_WorldIntersections,
    SEOutputDataId.SERightClosestWorldIntersection: SETypeId.SEType_WorldIntersection,
    SEOutputDataId.SERightAllWorldIntersections: SETypeId.SEType_WorldIntersections,
    SEOutputDataId.SEFilteredLeftClosestWorldIntersection: SETypeId.SEType_WorldIntersection,
    SEOutputDataId.SEFilteredLeftAllWorldIntersections: SETypeId.SEType_WorldIntersections,
    SEOutputDataId.SEFilteredRightClosestWorldIntersection: SETypeId.SEType_WorldIntersection,
    SEOutputDataId.SEFilteredRightAllWorldIntersections: SETypeId.SEType_WorldIntersections,
    SEOutputDataId.SEEstimatedLeftClosestWorldIntersection: SETypeId.SEType_WorldIntersection,
    SEOutputDataId.SEEstimatedLeftAllWorldIntersections: SETypeId.SEType_WorldIntersections,
    SEOutputDataId.SEEstimatedRightClosestWorldIntersection: SETypeId.SEType_WorldIntersection,
    SEOutputDataId.SEEstimatedRightAllWorldIntersections: SETypeId.SEType_WorldIntersections,
    SEOutputDataId.SEFilteredEstimatedClosestWorldIntersection: SETypeId.SEType_WorldIntersection,
    SEOutputDataId.SEFilteredEstimatedAllWorldIntersections: SETypeId.SEType_WorldIntersections,
    SEOutputDataId.SEFilteredEstimatedLeftClosestWorldIntersection: SETypeId.SEType_WorldIntersection,
    SEOutputDataId.SEFilteredEstimatedLeftAllWorldIntersections: SETypeId.SEType_WorldIntersections,
    SEOutputDataId.SEFilteredEstimatedRightClosestWorldIntersection: SETypeId.SEType_WorldIntersection,
    SEOutputDataId.SEFilteredEstimatedRightAllWorldIntersections: SETypeId.SEType_WorldIntersections,
    SEOutputDataId.SEAllWorldConeIntersections: SETypeId.SEType_WorldConeIntersections,
    SEOutputDataId.SELeftAllWorldConeIntersections: SETypeId.SEType_WorldConeIntersections,
    SEOutputDataId.SERightAllWorldConeIntersections: SETypeId.SEType_WorldConeIntersections,
    SEOutputDataId.SEFilteredAllWorldConeIntersections: SETypeId.SEType_WorldConeIntersections,
    SEOutputDataId.SEFilteredLeftAllWorldConeIntersections: SETypeId.SEType_WorldConeIntersections,
    SEOutputDataId.SEFilteredRightAllWorldConeIntersections: SETypeId.SEType_WorldConeIntersections,
    SEOutputDataId.SELeftBlinkClosingMidTime: SETypeId.SEType_u64,
    SEOutputDataId.SELeftBlinkOpeningMidTime: SETypeId.SEType_u64,
    SEOutputDataId.SELeftBlinkClosingAmplitude: SETypeId.SEType_f64,
    SEOutputDataId.SELeftBlinkOpeningAmplitude: SETypeId.SEType_f64,
    SEOutputDataId.SELeftBlinkClosingSpeed: SETypeId.SEType_f64,
    SEOutputDataId.SELeftBlinkOpeningSpeed: SETypeId.SEType_f64,
    SEOutputDataId.SERightBlinkClosingMidTime: SETypeId.SEType_u64,
    SEOutputDataId.SERightBlinkOpeningMidTime: SETypeId.SEType_u64,
    SEOutputDataId.SERightBlinkClosingAmplitude: SETypeId.SEType_f64,
    SEOutputDataId.SERightBlinkOpeningAmplitude: SETypeId.SEType_f64,
    SEOutputDataId.SERightBlinkClosingSpeed: SETypeId.SEType_f64,
    SEOutputDataId.SERightBlinkOpeningSpeed: SETypeId.SEType_f64,
    SEOutputDataId.SELeftEyeOuterCorner3D: SETypeId.SEType_Point3D,
    SEOutputDataId.SELeftEyeInnerCorner3D: SETypeId.SEType_Point3D,
    SEOutputDataId.SERightEyeInnerCorner3D: SETypeId.SEType_Point3D,
    SEOutputDataId.SERightEyeOuterCorner3D: SETypeId.SEType_Point3D,
    SEOutputDataId.SELeftNostril3D: SETypeId.SEType_Point3D,
    SEOutputDataId.SERightNostril3D: SETypeId.SEType_Point3D,
    SEOutputDataId.SELeftMouthCorner3D: SETypeId.SEType_Point3D,
    SEOutputDataId.SERightMouthCorner3D: SETypeId.SEType_Point3D,
    SEOutputDataId.SELeftEar3D: SETypeId.SEType_Point3D,
    SEOutputDataId.SERightEar3D: SETypeId.SEType_Point3D,
    SEOutputDataId.SELeftEyeOuterCorner2D: SETypeId.SEType_Vector,
    SEOutputDataId.SELeftEyeInnerCorner2D: SETypeId.SEType_Vector,
    SEOutputDataId.SERightEyeInnerCorner2D: SETypeId.SEType_Vector,
    SEOutputDataId.SERightEyeOuterCorner2D: SETypeId.SEType_Vector,
    SEOutputDataId.SELeftNostril2D: SETypeId.SEType_Vector,
    SEOutputDataId.SERightNostril2D: SETypeId.SEType_Vector,
    SEOutputDataId.SELeftMouthCorner2D: SETypeId.SEType_Vector,
    SEOutputDataId.SERightMouthCorner2D: SETypeId.SEType_Vector,
    SEOutputDataId.SELeftEar2D: SETypeId.SEType_Vector,
    SEOutputDataId.SERightEar2D: SETypeId.SEType_Vector,
    SEOutputDataId.SENoseTip2D: SETypeId.SEType_Vector,
    SEOutputDataId.SEMouthShapePoints2D: SETypeId.SEType_Vector,
    SEOutputDataId.SELeftEarShapePoints2D: SETypeId.SEType_Vector,
    SEOutputDataId.SERightEarShapePoints2D: SETypeId.SEType_Vector,
    SEOutputDataId.SENoseShapePoints2D: SETypeId.SEType_Vector,
    SEOutputDataId.SELeftEyeShapePoints2D: SETypeId.SEType_Vector,
    SEOutputDataId.SERightEyeShapePoints2D: SETypeId.SEType_Vector,
    SEOutputDataId.SELeftEyelidState: SETypeId.SEType_u8,
    SEOutputDataId.SELeftEyelidStateQ: SETypeId.SEType_f64,
    SEOutputDataId.SERightEyelidState: SETypeId.SEType_u8,
    SEOutputDataId.SERightEyelidStateQ: SETypeId.SEType_f64,
    SEOutputDataId.SEUserMarker: SETypeId.SEType_UserMarker,
    SEOutputDataId.SECameraClocks: SETypeId.SEType_Vector,
    SEOutputDataId.SESpeaking: SETypeId.SEType_u8,
    SEOutputDataId.SESpeakingQ: SETypeId.SEType_f64,
    SEOutputDataId.SEProfileId: SETypeId.SEType_s32,
    SEOutputDataId.SEProfileIdQ: SETypeId.SEType_f64,
    SEOutputDataId.SEProfileIdState: SETypeId.SEType_u8,
    SEOutputDataId.SEDrowsiness9Level: SETypeId.SEType_u8,
    SEOutputDataId.SEDrowsiness9LevelQ: SETypeId.SEType_f64,
    SEOutputDataId.SEDrowsiness9LevelStatus: SETypeId.SEType_u8,
    SEOutputDataId.SEGlasses: SETypeId.SEType_u8,
    SEOutputDataId.SEGlassesQ: SETypeId.SEType_f64,
    SEOutputDataId.SEFaceMask: SETypeId.SEType_u8,
    SEOutputDataId.SEFaceMaskQ: SETypeId.SEType_f64,
    SEOutputDataId.SELeftEyeOccluded: SETypeId.SEType_u8,
    SEOutputDataId.SELeftEyeOccludedQ: SETypeId.SEType_f64,
    SEOutputDataId.SERightEyeOccluded: SETypeId.SEType_u8,
    SEOutputDataId.SERightEyeOccludedQ: SETypeId.SEType_f64,
    SEOutputDataId.SEAnger: SETypeId.SEType_u8,
    SEOutputDataId.SEAngerQ: SETypeId.SEType_f64,
    SEOutputDataId.SEDisgust: SETypeId.SEType_u8,
    SEOutputDataId.SEDisgustQ: SETypeId.SEType_f64,
    SEOutputDataId.SEHappiness: SETypeId.SEType_u8,
    SEOutputDataId.SEHappinessQ: SETypeId.SEType_f64,
    SEOutputDataId.SENeutral: SETypeId.SEType_u8,
    SEOutputDataId.SENeutralQ: SETypeId.SEType_f64,
    SEOutputDataId.SESadness: SETypeId.SEType_u8,
    SEOutputDataId.SESadnessQ: SETypeId.SEType_f64,
    SEOutputDataId.SESurprise: SETypeId.SEType_u8,
    SEOutputDataId.SESurpriseQ: SETypeId.SEType_f64,
    SEOutputDataId.SEValence: SETypeId.SEType_f64,
    SEOutputDataId.SEValenceQ: SETypeId.SEType_f64,
    SEOutputDataId.SEMood: SETypeId.SEType_s32,
    SEOutputDataId.SEMoodQ: SETypeId.SEType_f64,
    SEOutputDataId.SEDominantEmotion: SETypeId.SEType_s32,
    SEOutputDataId.SEDominantEmotionQ: SETypeId.SEType_f64,
}


def output_data_type(output_data_id: SEOutputDataId) -> Optional[SETypeId]:
    """Returns the data type for the output data identified by output_data_id."""
    return _OUTPUT_DATA_ID_TO_TYPE_ID.get(output_data_id)
